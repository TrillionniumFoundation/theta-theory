# Revision 63 journal package

Read paper.pdf and STRUCTURAL_PAPER.pdf as separate manuscripts. RESPONSE_TO_REFEREE.md answers both r40 reports.

Run python journal_verify.py with Python, PyMuPDF and a LaTeX installation. This verifies hashes, copies only source/ to a temporary directory, typesets both papers, and compares every page text and raster. No repository, retained history, or network is required. The manifest pins the qualified source commit. It is not a formal proof or priority certificate.
