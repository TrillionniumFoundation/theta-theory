# Current literature audit — Revision 82

## New finite-outcome comparison (checked 5 October 2026)

Primary sources rechecked: Mele and Bittel, *Optimal learning of quantum channels in diamond distance*, arXiv:2512.10214v3, revised 15 June 2026 (`https://arxiv.org/html/2512.10214v3`); Zambrano, Ramos-Calderer and Kueng, *Fast quantum measurement tomography with optimal error bounds*, Quantum 10, 2162, published 15 July 2026 (`https://quantum-journal.org/papers/q-2026-07-15-2162/`). The existing bibliography already records these versions and is retained byte-for-byte.

Mele–Bittel's general channel theorem applies to finite-output measurements; their Corollary III.9 supplies the binary operator-norm estimator used here. Thus neither finite-output measurement tomography nor the binary upper primitive is claimed as newly invented. The v82 reduction takes each `E_j` to `I/4+E_j/2` by public classical relabeling, uses the inherited confidence-optimal actual-control binary construction, and legalizes all effects simultaneously. The new horizontal comparison justifies operator accuracy of order `delta/(k sqrt N)` under future-N loss. The coherent adaptive lower and affine entropy/payload converse are separate proofs.

For Zambrano–Ramos-Calderer–Kueng, the stated worst-input one-use outcome TV dominates each component operator error. Their estimator, with a constant-factor balanced-tuple legalization, has sufficient future-loss budget `O(k² N delta^-2 d²[d+k+log(1/eta)])`. This follows by substitution into their own Theorem 2, not by claiming a lower bound on their estimator. Their known-input, no-retained-reference model differs from Choi acquisition with collective completed-output processing.

The horizontal purification method, volume packing, inward rounding, finite rational density and greedy nets have standard antecedents. The new claims concern their precise normalized tuple combination and the stated joint future-loss theorem. Existing boundary discrimination counterexamples for broader POVMs are not contradicted: the finite-outcome metric upper requires a positive balanced margin. No universal absence-of-prior-work claim or human priority clearance is made.

The complete inherited comparison below retains the theorem-level sources for all binary, instrument, boundary, streaming and structural results. Its historical revision heading is not a claim that v81 evidence qualifies v82.

---

# Revision 81 literature and theorem comparison

The active comparison is `editions/operational-comparison81.tex`. The current source check directly revisited Mele–Bittel, arXiv:2512.10214v3, Corollary III.9, Remark III.4 and Lemma IV.19, and Zambrano–Ramos-Calderer–Kueng, arXiv:2507.04500v3. The inherited normalization, input/reference access and upper-estimator attribution remain unchanged.

Section 64 adds a prescribed-denominator rational readout and finite uniform-risk certificate. Its inputs are elementary PSD-preserving approximation, a finite matrix net, product-state trace-norm telescoping, and the already credited statistical existence bound. It does not claim invention of rational approximation, epsilon nets, finite POVM realization or standard tomography. Its distinction from Section 63 is that a public finite list and exact rational checks replace the universal semialgebraic feasibility step while preserving the query order and fixed dictionary.

The current manuscript keeps the earlier continuous ideal readout proof and its credit to real algebraic geometry. Known discrete-design and efficient purification/tomography results are part of the comparison; the finite rational construction does not turn those existing algorithms into a new primitive or claim to improve their runtime. A general independent priority conclusion is still requested in the human review brief.

## Complete inherited v80 literature audit

The following detailed comparison is retained as the source-specific prior account. Its version labels and then-new characterizations refer to v80.

# Literature audit — Revision 80

This author-side audit accompanies `GTF-I-v80-resource-complete-learning`, following the v79 publication `0daec5b3e20e5bf778caa90a0cf54f26c1ea53fe`. The controlling external report remains **R51 on Revision 77**, exact reviewed head `5650842e0bc89ca6a8b6d6730115784f0d9ecc12`; it is preserved as `FROZEN_R51_REPORT.md`. Primary-source checks below were made on 4 October 2026. The complete v79 audit and its earlier detailed comparisons follow verbatim, and its original bytes are also archived in `predecessor-v79-audit/LITERATURE_AUDIT.md`.

The current additions concern an all-confidence interior learning law and a finite, computable trusted readout at that query order. They retain the existing Mele–Bittel estimator as an upper-bound input, explicitly credit diagonal-coin classicalisation and standard confidence amplification, and use established real algebraic geometry to synthesize a separate measurement. No first-result claim or independent human priority clearance is asserted. The journal ambition and the controlling referee's unresolved positioning and human-review questions are not settled by these source checks.

## Current theorem objects and their resources

The unknown device is the consuming binary classical-output channel associated with an ordered effect \(0\preceq E\preceq I_d\). It returns no residual quantum system or environment. An external reference can be retained. The future loss \(d_N\) allows arbitrary reference-assisted adaptive tests with at most \(N\) calls and uses unhalved trace norm, so \(d_1(E,F)=2\|E-F\|_{\mathrm{op}}\). Training budget \(M\), future horizon \(N\), transmitted bits, trusted-control precision and computational cost are separate quantities. The promised interior is \(\mathcal I_d=[I_d/4,3I_d/4]\).

Fresh-block size \(b=1\) includes independently prepared maximally entangled input/reference pairs followed by unrestricted collective output processing. It excludes coherent feeding of retained quantum outputs into future probe inputs. This distinction remains necessary when comparing a source's “one parallel block” of independent Choi copies with the block parameter used here.

| Object | Access and loss | Parameter range | Call or description order |
|---|---|---|---|
| Mele–Bittel Corollary III.9, as printed | Independent Choi inputs, collective readout; \(b=1\); one-use operator error \(\epsilon\), entire binary body | \(d\ge1\), \(0<\epsilon<1\), \(4e^{-4d^2}<\eta<1\) | \(1024d^2\epsilon^{-2}+O(d\epsilon^{-2}\log(1/\eta))\) |
| Section 62, **lem:binaryconfidenceupper80**, **cor:operatorconfidence80** | Same upper-bound acquisition, \(b=1\); lower permits unrestricted coherent adaptive training; one-use operator error | All \(d\ge1\), \(0<\eta\le1/8\); corollary \(0<\epsilon\le2^{-14}\) | \(\Theta(\epsilon^{-2}[d^2+d\log(1/\eta)])\), absolute constants |
| Section 62, **thm:interiorconfidence80** | Unknown \(E\in\mathcal I_d\); future \(d_N\) error \(\delta\); \(b=1\) upper, unrestricted coherent adaptive lower | All integers \(d,N\ge1\), \(0<\delta\le2^{-13}\), \(0<\eta\le1/8\) | \(\Theta(N\delta^{-2}[d^2+d\log(1/\eta)])\), absolute constants |
| Section 63, **lem:algebraicreadout80**, **thm:effectiveinterior80** | Same interior and future loss; independent Choi probes and synthesized algebraic conditional POVMs; fixed exact rational public dictionary | Same \(d,N\), with rational positive \(\delta\le2^{-13}\), \(\eta\le1/8\) | \(M=O(N\delta^{-2}[d^2+d\log(1/\eta)])\); \(B=\tfrac12d^2\log_2N+d^2\log_2(1/\delta)+O(d^2)\) |
| Retained Sections 58 and 62, full-body comparison | Entire binary effect body; fresh blocks of size at most \(b\), future loss | \(d\ge2\), \(1\le b\le N\), sufficiently small \(\delta>0\), \(0<\eta\le1/8\) | Fixed-dimensional \(\Theta_d((N^2/b)\delta^{-2}\log(1/\eta))\); improved explicit upper \(C N^2\delta^{-2}\min\{d^2+d\log(1/\eta),(d^4/b)\log(d/\eta)\}\). The interior supplies additional \(d^2N\delta^{-2}\) and \(dN\delta^{-2}\log(1/\eta)\) lower bounds; the full-body dimension dependence remains unmatched. |
| Retained Section 61, **thm:interiorentropy79**, **thm:interiorcodec79**, **thm:prefixrate79** | Interior future-loss covering, exact rational words, and one-way randomized expected prefix length | Dimension-uniform small-error range; exact public dictionary; stated prefix success convention | \(B=A_d+O(d^2)\), \(A_d=d^2\log_2(\sqrt N/\delta)\); expected prefix length \((1-\eta)A_d+O(d^2)\) under the retained model |

No confidence term is needed in the length of a successful decoded word: confidence affects the training procedure, while the same dictionary covers the parameter class. The source-dependent estimator, dimension and confidence lower bounds, finite readout, exact decoding and trusted-control error accumulation are separate proof obligations.

## Mele–Bittel: exact imported statements and derived extension

The current checked primary version is **2512.10214v3, 15 June 2026**, [primary HTML](https://arxiv.org/html/2512.10214v3) and [version record](https://arxiv.org/abs/2512.10214). Corollary III.9 has the restricted confidence range printed in the table. Lemmas III.7–III.8 supply the binary normalization and legal-effect reconstruction. Algorithm I.2, Figure 1 and Section III.2 use independent Choi acquisitions, followed by collective processing. Remark III.4, equation (165), states a conventional all-confidence amplification with sufficient order \(d^2\epsilon^{-2}\log(1/\eta)\).

The sharper all-confidence order in Section 62 is derived from that source rather than attributed to the printed corollary. Choose base failure \(q_d=2^{-3d}>4e^{-4d^2}\). At a fixed fraction of the target accuracy the source's cost is \(O(d^2\epsilon^{-2})\). Independent repetition, with \(k\) the smallest positive odd integer at least \(2\log_2(1/\eta)/d\), followed by majority-cluster selection, has bad-majority probability at most \(2^kq_d^{k/2}\le2^{-dk/2}\le\eta\). Its total cost is the claimed \(O(\epsilon^{-2}[d^2+d\log(1/\eta)])\). Thus the current argument uses a standard amplification mechanism with a dimension-dependent base confidence; it does not introduce a new tomography primitive.

The directly relevant confidence-lower-bound antecedents are **Lemma IV.19**, “Classicalisation of N-query strategies,” and **Corollary IV.20**, in Section IV.2. The latter gives \(\Omega(d\epsilon^{-2}\log(d/\eta))\) for sufficiently small \(\epsilon\), \(0<\eta<1/4\), and \(d\ge1\). Section 62 credits this diagonal-coin method at use and proves its own null-versus-coordinate reduction under the present future-loss and coherent-adaptive interface. The future-use separation uses a scalar Bernoulli witness. Revealing the diagonal basis index isolates the hypothesis-dependent Bernoulli coin after a common basis-dephasing map. The classical–quantum relative-entropy identity then treats different current quantum inputs under the two hypotheses, including coherent adaptive memory. Summing coordinate testing costs yields the confidence term. The retained near-fair matrix packing gives the dimension term. Taking the maximum of those two lower bounds, and using maximum at least half the sum, proves the additive joint order; multiplying independent lower bounds would be invalid.

This supports a positive answer to the estimator-reanalysis question on \(\mathcal I_d\): the dimension-free local bound \(d_N\le4\sqrt N\|E-F\|_{\mathrm{op}}\) transfers one-use accuracy of order \(\delta/\sqrt N\) to the joint interior law. The negative full-body answer remains: for fixed \(d\ge2\), every \(b=1\) acquisition procedure requires order \(N^2\delta^{-2}\log(1/\eta)\) in the worst case. Neither collective final readout nor another reconstruction from the same independent inputs evades that lower bound.

There is also a direct full-body upper improvement, recorded in Section 62. Substituting \(\epsilon=\delta/(2N)\) in **lem:binaryconfidenceupper80** and applying the hybrid inequality gives \(C N^2\delta^{-2}[d^2+d\log(1/\eta)]\) with independent Choi acquisition. That \(b=1\) procedure is admissible under every cap \(b\ge1\). Choosing between it and the retained horizon-blocking procedure gives
\[
 M_b^*(d,N,\delta,\eta)\le
 C\frac{N^2}{\delta^2}
 \min\!\left\{d^2+d\log\frac1\eta,
              \frac{d^4}{b}\log\frac d\eta\right\}
\]
for \(d\ge2\), \(1\le b\le N\), \(0<\delta\le\min\{2^{-13},\delta_*\}\), \(0<\eta\le1/8\). This is an upper-bound conversion of the credited estimator and an algorithm choice based on public parameters. It preserves the quadratic horizon cost of independent probes and does not supply a sharp full-body joint minimax law. The sharper interior law and the full-body boundary obstruction retain their different parameter classes.

The current checked Zambrano–Ramos-Calderer–Kueng version remains **2507.04500v3, 9 July 2026**, published in *Quantum* **10**, 2162; [primary HTML](https://arxiv.org/html/2507.04500v3), [version record](https://arxiv.org/abs/2507.04500). Its independent known-input acquisitions are also \(b=1\). The detailed loss normalization, global-design upper bound and restricted nonadaptive single-copy lower bound remain in the preserved audit below; the restrictions on that converse are not relaxed here.

## Effective algebraic readout and its computational limits

Section 63 synthesizes a **different** finite measurement. It does not purport to compute or discretize the entries of the imported Mele–Bittel readout. For a fixed number of independent Choi acquisitions, the subnormalized quantum state in each classical outcome block is a polynomial in the real coordinates of \(E\). A conditional finite POVM has finitely many real variables. Positivity, completeness, operator-norm balls about rational dictionary centres, and the universal success inequality over every real \(E\in\mathcal I_d\) are expressible using rational polynomial signs. Subnormalized blocks avoid division by outcome probabilities, including zero-probability branches. Dephasing in the classical output register preserves the statistics, so the construction does not assume coherent access to classical device outputs.

The foundations are Basu–Pollack–Roy, *Algorithms in Real Algebraic Geometry*, second edition (2006), **Theorems 2.77 and 2.80, Chapter 14**, [official DOI](https://doi.org/10.1007/3-540-33099-2), [author-posted book](https://perso.univ-rennes1.fr/marie-francoise.roy/bpr-ed2-posted1.pdf). Theorem 2.77 gives quantifier elimination preserving the coefficient ring; Theorem 2.80 gives transfer between real closed fields. With rational coefficients, a nonempty feasible set therefore has a real-algebraic point. Effective elimination decides emptiness; after a positive decision, enumeration of algebraic tuples and exact sign tests finds a witness. The readout variables remain free until the universal effect variables have been eliminated. This yields a guarantee for all real effects, not merely the algebraic effects used in an enumeration. The author-posted survey [Algorithms in Real Algebraic Geometry: A Survey](https://www.math.purdue.edu/~sbasu/raag_survey2011_final.pdf) independently provides an accessible account of effective elimination and algebraic sampling; its numbering must not be conflated with another survey version.

The algorithm decides feasibility for sample counts in increasing order. The imported statistical upper bound and the existing measurable dictionary coarsening establish existence by the required call order; rejecting each smaller infeasible count is decidable. The algorithm's input consists only of public integers and rational errors. It does not require a description or oracle for the unknown effect. Algebraic conditional POVMs admit finite algebraic dilations. The theorem then allocates a certified total error over preparations and the entire conditional readout instrument; it does not condition an approximation guarantee on an outcome of arbitrarily small probability.

Existing finite and efficient tomography must receive its own credit. Pelecanos–Spilecki–Tang–Wright, [2511.15806v1, primary HTML](https://arxiv.org/html/2511.15806v1), **Theorems 1.1–1.3, Section 3.3 and Figures 8–9**, provide efficient purification and state-tomography constructions; **Theorem 4.2** supplies the discrete approximate-design circuit ingredient. These are substantive algorithmic antecedents. An efficient replacement for a covariant state measurement does not by itself establish the same binary operator-error analysis in Mele–Bittel, whose covariance hypotheses require attention. Section 63 bypasses that issue through a new feasibility construction. Its guarantee is finite computability at the statistical query order, with a fixed exact dictionary and a universal risk certificate. It asserts no useful preprocessing, gate-count, workspace or algebraic-description-length bound, and no priority for finite quantum measurement implementation.

## Open scope and review status

The sharp growing-dimensional full-body minimax law, dimension-uniform boundary metric/entropy constants, efficient exact reconstruction, residual quantum outputs and general outcome number remain outside these new claims. “Resource-complete” identifies this revision directory; it is not a conclusion that every resource or model is resolved. The standard mechanisms credited above, and the previous detailed geometry, metrology, channel-learning and coding comparisons, remain necessary context.

An independent human specialist still needs to assess correctness, closest theorem overlap and positioning. `INDEPENDENT_REVIEW_BRIEF.md` supplies concrete checks, including the additive all-confidence law, coherent classicalisation, universal risk formula, termination, precision budget and nearest prior finite implementations. No outside communication has occurred, and no build result or author-side audit is treated as that review.

## Complete predecessor v79 audit (historical text)

The following predecessor text is preserved verbatim. Its date-specific checks and descriptions of the then-current additions remain historical records; the current scope and confidence ranges are those stated above.

---

# Literature audit — Revision 79

The current primary-source comparison was checked against Mele–Bittel, arXiv:2512.10214v3 (15 June 2026), in its primary HTML version. Corollary III.9 and the binary operator-norm identity remain the imported estimator input, as specified in the preserved audit. The new learned-description theorem does not claim that estimator as an invention of this paper.

The new contribution is a dimension-uniform operational description law on the same promised interior, an exact public rational dictionary at that rate, its one-way randomized expected-prefix variant, and joint learning/transmission in the stated ideal-control model. Norm-ball volume comparison, greedy nets, Kraft's inequality, Fano's inequality, public erasure and measurable coarsening are standard mechanisms. The paper proves their specific combination with the dimension-free future-use metric rather than attributing those mechanisms to this revision. No new literature claim that the four theorem objects are globally first is made. The nearest-neighbour priority questions remain in the human specialist brief.

## Complete predecessor theorem-level audit (historical text)

The following is preserved verbatim. Its claims about what was new in v78 and its date-specific checks are records of that stage.

---

# Theorem-level literature comparison — Revision 78

Current primary-source checks were made on 4 October 2026. This author-side comparison responds to **FROZEN_R51_REPORT.md**, especially Sections 6.3, 6.5 and required revisions 2, 4, 5 and 10. That report reviewed completed Revision 77 head `5650842e0bc89ca6a8b6d6730115784f0d9ecc12`. The full preceding audit is preserved as `predecessor-v77-audit/LITERATURE_AUDIT.md`, with its older predecessor comparisons intact. Original focused and complete bibliographies were copied into the matching `predecessor-v77-audit` paths before appending new entries.

The principal R51 increment is a theorem about **fresh quantum training blocks for the entire unknown ordered binary effect body under future-use loss**. The block dependence uses established metrological and fidelity methods. A sharper Mele–Bittel analysis is also supplied on a promised interior class. Those two claims distinguish exactly where estimator reanalysis can improve the horizon rate and where a direct acquisition lower bound rules it out. No independent human specialist has supplied a correctness or priority judgment; the actionable questions remain open in `INDEPENDENT_REVIEW_BRIEF.md`.

## Objects submitted for comparison

The target class is the entire matrix interval
\[
\mathfrak E_d=\{E=E^*:0\le E\le I_d\},\qquad
\mathcal M_E(\rho)=\operatorname{tr}(E\rho)|1\rangle\langle1|
+\operatorname{tr}((I-E)\rho)|0\rangle\langle0|.
\]
The outcomes are ordered. Calls are memoryless and consume the input; no residual quantum system or measurement environment is returned by the device. A tester can retain an external reference and use intermediate channels and classical feedback. Trace distance is unhalved. In particular, \(d_1(E,F)=2\|E-F\|_{\mathrm{op}}\). The nonadaptive class still permits entanglement across the input block and a retained reference; it excludes feedback between calls. All finite dimensions are included, and covering constants may depend on dimension.

Section 53, **thm:matrixmetric76**, compares the nonadaptive and adaptive distances for every pair and every finite horizon. With \(A=(E+F)/2\), \(H=F-E\), \(V=A(I-A)\), and left and right multiplication denoted by \(L,R\),
\[
Q_N(E,F)^2=N\langle H,(L_V+R_V+N^{-1}\mathrm{Id})^{-1}H\rangle_{\mathrm{HS}},
\]
and
\[
\frac{\min(1,Q_N)}{8192d}\le d_N^{\mathrm{na}}(E,F)
\le d_N^{\mathrm{ad}}(E,F)\le\min(2,8Q_N).
\]
Section 54, **thm:matrixcover76**, gives, uniformly in \(N\ge1\) and in a sufficiently small positive error range depending only on \(d\),
\[
\mathcal C_N(\mathfrak E_d,\delta)\asymp_d
N^{d^2/2}[\log(N+2)]^{\lfloor d/2\rfloor}\delta^{-d^2}.
\]
The lower bound allows arbitrary legal centres; rational legal centres achieve the same order. Section 55, **thm:commonlearn76**, supplies the common binary-qubit learner used as a subroutine in the following all-dimensional result.

Section 56, **thm:matrixlearning77**, proves that one procedure, without supplied spectral data, returns a legal classical estimate satisfying
\[
 \sup_{E\in\mathfrak E_d}
 \mathbb P_E\{d_N(\mathcal M_E,\mathcal M_{\widehat E})>\delta\}
 \le\eta,
 \qquad
 M\le C d^4N\delta^{-2}\log(d/\eta).
\]
Here \(d,N\ge1\), \(0<\delta\le\delta_0\), and \(0<\eta\le1/8\); \(C,\delta_0\) are absolute. The bound holds on every record, and each entangled input block has length at most \(N\). Its scalar-subfamily converse is
\[
 M\ge cN\delta^{-2}\log(1/\eta)
\]
even for arbitrary reference-assisted adaptive training with bounded public stopping. Thus the minimax order is \(\Theta_d(N\delta^{-2}\log(1/\eta))\) for each fixed \(d\). Optimality of the displayed \(d^4\) factor is not asserted. The future comparison horizon \(N\), training calls \(M\), entangled block length, and classical computational work are separate resources.

Section 57, **thm:matrixcodec77**, constructs an ordered dictionary by finite exact rational arithmetic for every \(d,N\ge1\) and rational \(0<\delta\le1\). Encoding a supplied Gaussian-rational effect and decoding its index both terminate. The decoded effect has error at most \(11\delta/16\). The dictionary size has the covering order above as an upper bound throughout this range, and its index length, for \(0<\delta\le\delta_d\), is
\[
 \frac{d^2}{2}\log_2N+
 \lfloor d/2\rfloor\log_2\log(N+2)+
 d^2\log_2(1/\delta)+O_d(1).
\]
Both parties reconstruct the dictionary from public \((d,N,\delta)\); no centre coordinates or target-dependent advice are omitted from the payload. This is a finite exact optimal-order description theorem. The construction does not claim polynomial running time in the payload length. Earlier structural results, the contact results, and the direct qubit code remain available under their own hypotheses.

## Measurement discrimination: direct antecedents

**Fiurášek–Mičuda (2009), FM75.** [Full text](https://arxiv.org/pdf/0909.2940), [published article](https://doi.org/10.1103/PhysRevA.80.042312). Sections I, III and IV compare two-use projective-qubit protocols; equation (16) treats adaptive product probes and equations (27)–(30) give entangled feed-forward constructions. Their interface excludes additional ancillary measurements. This restriction matters when comparing with the later reference-assisted projective theorem.

**Sedlák–Ziman (2014), SZ74.** [Full text](https://arxiv.org/pdf/1408.0934), [published article](https://doi.org/10.1103/PhysRevA.90.052312). Theorem 1 characterizes perfect single-use discrimination of binary measurements. Section VI, Example 4, equation (37), allows unequal white-noise visibilities and reduces the one-use problem to mixed-qubit-state discrimination. Those effects are unbiased. For \(E=((1+b)I+x\cdot\sigma)/2\), the elementary identity \(\Gamma(E)-(I-E)=bI\) explains why this particular spin-flip reduction does not itself treat bias.

**Puchała–Pawela–Krawiec–Kukulski (2018), PPKK74.** [Full text](https://arxiv.org/pdf/1804.05856), [published article](https://doi.org/10.1103/PhysRevA.98.042103). Theorem 1, equation (19), represents the single-use diamond distance between von Neumann measurements by a minimization over diagonal phases of a unitary-channel distance. Assigning this representation to arbitrary nonprojective effects would require another argument.

**Puchała–Pawela–Krawiec–Kukulski–Oszmaniec (2021), PPKKO72.** [Full text](https://arxiv.org/pdf/1810.05122v4), [published article](https://quantum-journal.org/papers/q-2021-04-06-425/). Corollary 1 gives an exact finite-use parallel distance for von Neumann measurements; Theorem 2 proves optimality among general networks with ancillary access. This supplies an exact projective endpoint. The new constant-factor comparison does not assert exact parallel optimality for all effects.

**Krawiec–Pawela–Puchała (2020), KPP76, requested in r49.** [Full text](https://arxiv.org/pdf/2002.05452v1), [published article](https://doi.org/10.1007/s11128-020-02883-3). Sections 2–3 allow retained references and adaptive intermediate channels and study finite-use perfect discrimination of rank-one POVMs. Section 4 constructs two differently ordered nine-outcome qutrit SIC measurements admitting a two-use adaptive perfect test but no finite parallel perfect test. This is a direct repeated-measurement antecedent. It concerns two hypotheses, not two outcomes. The checked results do not give the present binary-body midpoint comparison or covering law. Requiring both effects of a binary qubit POVM to have rank one forces a projective measurement; for \(d>2\) their ranks cannot sum to \(d\).

**Datta–Biswas–Saha–Augusiak (2021), DBSA76, requested in r49.** [Full text](https://arxiv.org/pdf/2012.07069v2), [published article](https://doi.org/10.1088/1367-2630/abecaf). A destructive unknown measurement on one half of an entangled input is followed by an outcome-dependent known measurement on the reference. Theorem 1 relates entanglement advantage to steerability; Theorems 2–4 construct perfect-discrimination examples with multiple outcomes. Theorem 5 gives an advantage using any pure entangled two-qubit state for a pair of three-outcome POVMs. These are single-use results; their hypothesis and outcome counts must remain distinct in the comparison.

## Kraus geometry and finite-use channel bounds

**Fujiwara–Imai (2008), FI76.** [Publisher](https://doi.org/10.1088/1751-8113/41/25/255304), [author-uploaded full text](https://www.researchgate.net/publication/231040616_A_fibre_bundle_over_manifolds_of_quantum_channels_and_its_application_to_quantum_statistics). Theorem 4 expresses maximal reference-assisted quantum Fisher information through minimization over differentiable Kraus representations. Theorem 5 identifies a vanishing Kraus cross derivative that gives linear growth for repeated parallel use. Horizontal Kraus lifts and the orthogonality mechanism are established tools.

**Channel extension and adaptive bounds.** Demkowicz-Dobrzański–Kołodyński–Guţă (2012), DKG67, [full text](https://arxiv.org/pdf/1201.3940v2), equations (10)–(13) in this arXiv version, bound parallel quantum Fisher information using the usual Kraus quantities \(\alpha,\beta\). Demkowicz-Dobrzański–Maccone (2014), DM76, [full text](https://arxiv.org/pdf/1407.2934v3), equation (9), gives an adaptive bound whose \(\beta=0\) specialization is \(4N\|\alpha\|\). Kurdziałek–Górecki–Albarelli–Demkowicz-Dobrzański (2023), KGAD76, [full text](https://arxiv.org/pdf/2212.08106v2), equations (5) and (8)–(10), provides an adaptive recursion with the same specialization. In **lem:matrixpath76**, equation **eq:horizontaloverlap76** has \(\alpha=K^2\) and \(\beta=0\). The cancellation under arbitrary controls is consequently an application of the established method, explicitly checked for the present qc dilation and tester interface.

**Integration to finite pairs.** Yuan–Fung, YF76, [full text](https://arxiv.org/pdf/1506.00819v3), Section III, equation (26), integrates quantum Fisher information along a path to bound the Bures angle between finite channel hypotheses in parallel discrimination. Sieniawski–Demkowicz-Dobrzański (2026), SD76, [full text](https://arxiv.org/pdf/2510.15506v3), Section IV.A, equations (14)–(22), uses this connection with adaptive metrological bounds. The latter expressly cites the earlier integration argument. Neither passage from a differential bound to a finite path nor its adaptive use is claimed as new here.

These locators refer to the specified PDF versions. In particular, Yuan–Fung's v3 PDF labels the path integral equation (26), on page 8; its experimental HTML rendering numbers the same expression (28). The manuscript retains the PDF locator. For Sieniawski–Demkowicz-Dobrzański, equations (14)–(16) connect trace distance, Bures angle and the path integral; equations (19)–(22) apply adaptive quantum Fisher information bounds. These are the exact antecedents at the integration step of **lem:matrixpath76**.

Section 53 instead supplies a specific Sylvester construction involving \(\sqrt{E(I-E)}\) for a binary qc dilation, controls a residual derivative at the finite-horizon scale, and integrates the straight segment to obtain the displayed midpoint resolvent. Legal scalar and two-dimensional compressions give its matching lower estimate. This explicit closed-body comparison is the object requiring priority assessment; a general local Fisher information bound alone does not identify it.

## Inverse Sylvester forms and spectral volume

**Dittmann (1999), Dittmann76.** [Full text](https://arxiv.org/pdf/quant-ph/9808044), [published article](https://doi.org/10.1088/0305-4470/32/14/007). Equations (1)–(2) give the Bures tensor on the positive matrix cone as
\[
g^B_W(H,H)=\tfrac12\langle H,(L_W+R_W)^{-1}H\rangle.
\]
Algebraically, \(Q_N^2/N=2g^B_W(H,H)\) at \(W=A(I-A)+(2N)^{-1}I\). The inverse Sylvester form itself is classical. This identity is not a Bures pullback through the variance map: that map has differential \(H-AH-HA\), whereas the operational comparison retains \(H\).

**Sommers–Życzkowski (2003), SZGeom76.** [Full text](https://arxiv.org/pdf/quant-ph/0304041), [published article](https://doi.org/10.1088/0305-4470/36/39/308). Section III, especially equations (3.12)–(3.17), develops spectral coordinates, the eigenvalue Jacobian and volume integration for Bures geometry. These are antecedents for calculating a unitarily invariant matrix volume. Its normalized state body and metric differ from the effect interval and finite-horizon variance tensor here.

In Section 54 the determinant computation yields a spectral density proportional to
\[
N^{d^2/2}\prod_i[2\lambda_i(1-\lambda_i)+N^{-1}]^{-1/2}
\prod_{i<j}\frac{(\lambda_i-\lambda_j)^2}
{\lambda_i(1-\lambda_i)+\lambda_j(1-\lambda_j)+N^{-1}}.
\]
The proof establishes uniform volume bounds for operational balls on the closed matrix interval before deriving coverings from this integral. It then counts nested scales near the two opposite spectral endpoints: balanced endpoint prefixes produce \(\lfloor d/2\rfloor\) logarithmic factors. The checked sources do not state this asymptotic or its operational covering consequence. That is a bounded search result, not proof that an equivalent result cannot exist elsewhere.

## Common estimation: verified access, loss, confidence, and parameter ranges

The notation is standardized here: \(M\) counts training calls, \(N\) is the future comparison horizon, \(b\) bounds calls in one fresh quantum experiment, \(\epsilon\) is one-use operator accuracy, and \(\eta\) is failure probability. Both main tomography papers already construct one common classical estimator of an unknown measurement. The new theorem does not originate that statistical task.

**Mele–Bittel, MB67.** [Current version record](https://arxiv.org/abs/2512.10214v3), [full HTML](https://arxiv.org/html/2512.10214v3), [PDF](https://arxiv.org/pdf/2512.10214v3). The checked version is v3, 15 June 2026. Algorithm I.2, Figure 1 and Section III.2 prepare independent maximally entangled input/reference pairs; coherent purification and tomography subsequently act on the Choi copies. There are no additional unknown-channel calls during that processing. Therefore these acquisitions satisfy **def:freshblocks78** with \(b=1\), even though the source calls all simultaneous invocations a single parallel block. The operational restriction concerns connections between queried inputs, not simultaneous execution or the size of a final measurement.

Theorem I.1 gives \(O(d_{\rm in}d_{\rm out}k\epsilon^{-2})\) at fixed confidence for Kraus rank at most \(k\). Lemmas III.7–III.8 give the binary identity \(\|\mathcal M_E-\mathcal M_F\|_\diamond=2\|E-F\|_{\rm op}\) and extract a legal effect. Corollary III.9 uses \(k=2d\), allows every effect rank, and states
\[
 M=1024d^2\epsilon^{-2}+O(d\epsilon^{-2}\log(1/\eta)),
 \quad \mathbb P\{\|\widehat E-E\|_{\rm op}\le\epsilon\}\ge1-\eta,
 \quad 0<\epsilon<1,\quad 4e^{-4d^2}<\eta<1.
\]
The unsimplified Theorem III.2 permits arbitrary confidence. Remark III.4, equation (165), supplies the alternative sufficient order \(O(d^2\epsilon^{-2}\log(1/\eta))\) by repetition for all \(0<\eta\le1/8\); repetition and reconstruction preserve \(b=1\). At \(\eta=1/8\), Corollary III.9's restriction holds for every \(d\ge1\).

**Zambrano–Ramos-Calderer–Kueng, ZRK76.** [Current version record](https://arxiv.org/abs/2507.04500v3), [full HTML](https://arxiv.org/html/2507.04500v3), [published article](https://quantum-journal.org/papers/q-2026-07-15-2162/). The checked version is v3, 9 July 2026; the publication is *Quantum* **10** (2026), 2162. Section 3.1 collects the unknown POVM's outcomes on known individual probe states. The acquisition is nonadaptive and single-copy, without retained references, hence \(b=1\). Entanglement among the constituent qubits of a single \(d\)-dimensional global-design probe does not couple separate device calls.

Definition 1 uses worst-input one-use outcome total variation. For \(L=2\) this is exactly \(\|E-F\|_{\rm op}\). Theorem 2, equation (13), states the sufficient global-\(2\)-design budget
\[
 M\ge\frac{8(d^2+\epsilon(d^2+1)/6)}{\epsilon^2}
       \log\frac{2^{L+1}9^{2d}}{\eta}.
\]
The protocol uses least squares followed by legal projection and has no effect-rank promise. The displayed expression applies for positive accuracy and \(0<\eta<1\); the comparison table uses \(0<\epsilon<1\). Its local-product-design variant has a different dimension factor. Theorem 9, equation (43), proves \(\Omega((d^3+d^2L)\epsilon^{-2})\) at constant success probability within the stated nonadaptive single-copy known-input model.

### Theorem-level comparison table

The future-loss rows use an absolute sufficiently small \(\delta>0\). “Full body” means the entire ordered binary effect body; “interior” means the promised class \(I/4\preceq E\preceq3I/4\). The new block law has \(d\ge2\); the scalar exception is stated below.

| Theorem or conversion | Acquisitions and \(b\) | Loss and domain | Horizon \(N\) and dimension \(d\) | Confidence and call budget \(M\) |
|---|---|---|---|---|
| MB67, Corollary III.9 | Independent Choi probes, collective subsequent processing; \(b=1\) | One-use operator error \(\epsilon\); full body | Every \(d\ge1\); no future horizon in the theorem | \(4e^{-4d^2}<\eta<1\): \(1024d^2\epsilon^{-2}+O(d\epsilon^{-2}\log(1/\eta))\) |
| MB67, Remark III.4 amplification | Same fresh single-call acquisitions; \(b=1\) | One-use operator error \(\epsilon\); full body | Every \(d\ge1\) | All \(0<\eta\le1/8\): \(O(d^2\epsilon^{-2}\log(1/\eta))\) |
| ZRK76, Theorem 2, global designs, \(L=2\) | Known separate probe states, no reference; \(b=1\) | One-use operator error \(\epsilon\); full body | Every input dimension | All \(0<\eta<1\): \(O(d^2\epsilon^{-2}[d+\log(1/\eta)])\) |
| Direct hybrid transfer of MB67 | \(b=1\) | Future \(d_N\) error \(\delta\); full body | \(N\ge1\), every \(d\) | \(O(d^2N^2\delta^{-2}\log(1/\eta))\), a sufficient budget |
| Direct hybrid transfer of ZRK76 | \(b=1\) | Future \(d_N\) error \(\delta\); full body | \(N\ge1\), every \(d\) | \(O(d^2N^2\delta^{-2}[d+\log(1/\eta)])\), a sufficient budget |
| Revision 78, **thm:interiorlearning78**, using MB67 | Independent Choi probes; \(b=1\); converse permits fully coherent adaptive training | Future \(d_N\) error \(\delta\); promised interior | Joint dimension/horizon/accuracy order | \(\eta=1/8\): \(\Theta(d^2N\delta^{-2})\) |
| Retained **thm:matrixlearning77** | Fresh blocks of at most \(N\); classical adaptive calibration | Future \(d_N\) error \(\delta\); full body | \(N\ge1\), every fixed \(d\) | \(0<\eta\le1/8\): \(\Theta_d(N\delta^{-2}\log(1/\eta))\); upper \(Cd^4N\delta^{-2}\log(d/\eta)\) |
| Revision 78, **thm:blocklearning78** | Fresh quantum blocks of length at most \(b\), classical feedback, arbitrary output memory and joint processing | Future \(d_N\) error \(\delta\); full body | \(d\ge2\), \(1\le b\le N\) | \(0<\eta\le1/8\): \(\Theta_d((N^2/b)\delta^{-2}\log(1/\eta))\); upper factor \(Cd^4\log(d/\eta)\) |
| Revision 78, **cor:onecallseparation78** | Every acquisition in the larger fresh \(b=1\) class | Future \(d_N\) error \(\delta\); full body | \(d\ge2\), \(N\ge1\) | Necessary \(\Omega(N^2\delta^{-2}\log(1/\eta))\); applies to any reconstruction of MB67/ZRK76 acquisitions |

### The R51 estimator-reanalysis question has two different answers

The hybrid inequality \(d_N(E,F)\le2N\|E-F\|_{\rm op}\), by itself, certifies only sufficient budgets. Revision 77 correctly left stronger estimator analysis open on that evidence. Revision 78 adds an independent minimax converse for the actual acquisitions: every full-body learner with \(b=1\) has a worst-case \(\Omega(N^2\delta^{-2}\log(1/\eta))\) cost. Its adversarial projective pair is available in every \(d\ge2\). Therefore a new analysis or a different classical/collective reconstruction of the checked MB67 or ZRK76 acquisitions cannot yield the full-body \(O_d(N\delta^{-2}\log(1/\eta))\) law. The assertion concerns uniform worst-case risk, rather than pointwise difficulty at every effect or optimal dimension factors for those protocols.

On the promised interior class, a stronger analysis **does** help. If \(I/4\preceq E\preceq3I/4\) and a legal \(F\) satisfies \(\|E-F\|_{\rm op}\le1/8\), the horizontal path argument gives
\[
 d_N(E,F)\le4\sqrt N\|E-F\|_{\rm op}.
\]
Thus **thm:interiorlearning78** applies the actual legal binary estimator of MB67 Corollary III.9 at \(\epsilon=\delta/(8\sqrt N)\), \(\eta=1/8\), and obtains \(O(d^2N\delta^{-2})\) fresh single-call training. The new dimension lower bound matches it on this interior class. The improvement uses a promise excluding the projective boundary; it does not contradict **cor:onecallseparation78**. For smaller failure probabilities, MB67's amplification gives the sufficient interior budget \(O(d^2N\delta^{-2}\log(1/\eta))\); joint optimality of that multiplied dimension/confidence expression is not asserted.

## Fresh quantum blocks: exact claim, proof ingredients, and priority boundary

**Definition and range.** In **def:freshblocks78**, each classical history selects a length \(1\le t\le b\) and a fresh tester. Conditional on that history, the entire tester, including unused inputs and its reference, starts in a parameter-independent state tensor-separated from old quantum storage and remains isolated until its last call. Inside the block arbitrary reference-assisted adaptive quantum control is allowed. At boundaries all stored systems may be processed by a common instrument, whose classical result selects the next fresh tester. An arbitrary collective final readout is allowed. Declared block lengths are charged in full and sum to at most \(M\) on every record, including stopped and unsuccessful records. This is a restriction on feeding quantum information into future probes; it does not bound output-memory size.

For \(d\ge2\), \(1\le b\le N\), \(0<\delta\le\delta_*\), \(0<\eta\le1/8\), **thm:blocklearning78** gives
\[
 c\frac{N^2}{b\delta^2}\log\frac1\eta
 \le M_b^\star(d,N,\delta,\eta)
 \le Cd^4\frac{N^2}{b\delta^2}\log\frac d\eta.
\]
The constants are absolute, and \(\delta_*\) is at most the retained learner's small-error cap and \(1/4\). For \(d=1\), the correct law is instead \(\Theta(N\delta^{-2}\log(1/\eta))\), independently of \(b\). There is no projective angular subfamily in dimension one.

**Finite-pair and confidence argument.** The block lower bound uses a projective qubit rotation embedded in the full effect body. On the active two-dimensional space, the exact projective finite-use distance is \(2\sin(N|\theta|/2)\) in its local range; the multiple-shot projective discrimination theorem **PPKKO72** is a direct antecedent. **lem:blockfidelity78** bounds the root fidelity after a fresh \(t\)-call experiment by \(\cos(t|\theta|/2)\). When \(b|\theta|\le1\), the subnormalized classical–quantum branch calculation yields
\[
 \mathfrak f(\Gamma_0,\Gamma_\theta)\ge e^{-Mb\theta^2/4}.
\]
A history-weighted potential retains the actual charged call count. Tensor-product fidelity is used only conditionally on the same history; common instruments use direct-sum fidelity and data processing. Taking \(\theta=4\delta/N\) gives disjoint future-loss success balls. Testing them yields \(M\ge N^2\log(1/\eta)/(24b\delta^2)\). This establishes the confidence term for biased estimators and bounded stopping without converting a local Cramér–Rao bound into a global risk claim.

**Upper bound and synthesis.** **lem:blockhybrid78** gives \(d_N\le\lceil N/b\rceil d_b\). Applying the retained all-effect common learner with horizon \(b\) and accuracy \(\delta/\lceil N/b\rceil\) yields the upper bound. That reduction is a standard hybrid blocking argument. The hard part inherited by the common learner remains unknown-endpoint calibration, controlled compression, and noise-adapted phase learning across the closed body. The block interpolation is a resource consequence of that learner plus a finite-confidence converse; no separate invention of the standard metrological gain is claimed.

**Hyllus et al., Hyllus78; Tóth, Toth78.** [Hyllus PDF, v3](https://arxiv.org/pdf/1006.4366), [version record](https://arxiv.org/abs/1006.4366), [Tóth full text, v3](https://arxiv.org/html/1006.4368v3), [published Hyllus article](https://doi.org/10.1103/PhysRevA.85.022321), [published Tóth article](https://doi.org/10.1103/PhysRevA.85.022322). Hyllus et al., Section III.A, Observation 1, equation (9), and Tóth, Observation 3, equation (6), bound quantum Fisher information of \(b\)-producible qubit probes under linear phase encoding by
\[
 \lfloor M/b\rfloor b^2+(M-b\lfloor M/b\rfloor)^2\le Mb.
\]
These are established resource-tradeoff antecedents. The manuscript's blocks can also contain sequential adaptive quantum controls, so \(b\) is not asserted to equal entanglement depth of an arbitrary final state. The authors' literal derivation of the all-body law and finite confidence/stopping argument must be assessed beyond the shared scale.

**Salek–Hayashi–Winter, SHW68.** [Full text, arXiv:2011.06569v3](https://arxiv.org/html/2011.06569v3), [published article](https://doi.org/10.1103/PhysRevA.105.022419). Section II.2, equations (1)–(3), explicitly permits classical adaptive inputs, receiver quantum memory, instruments combining the new output with that memory, and a collective final test. Section V.2, Theorem 9, treats general channel inputs without input-side quantum memory through classical–quantum channel discrimination. This is a close model and method antecedent. Applying such a viewpoint to the classical alphabet of fresh tester specifications is natural. Its asymptotic exponent equalities do not themselves state the present uniform finite-budget, variable-length, high-confidence learning theorem.

**Wilde–Berta–Hirche–Kaur, WBHK72.** [Full text, arXiv:1808.01498v2](https://arxiv.org/html/1808.01498v2), [published article](https://doi.org/10.1007/s11005-020-01297-7). Lemma 14 supplies adaptive divergence meta-converses; Proposition 21, equations (156)–(160), uses fidelity to bound symmetric testing error, and Appendix B proves the generalized Fuchs–van de Graaf inequality. These are prior finite-testing tools. The conditional branch-potential proof is stated directly in Section 58 so its specific fresh-block restriction, stopping convention and confidence range can be checked.

**Bounds on joint measurements of supplied states are another resource.** Chen–Li–Liu, **CLL78**, [arXiv:2402.16353v1](https://arxiv.org/abs/2402.16353v1), study an entanglement/copy-complexity tradeoff when each tomography measurement acts on at most \(t\) supplied state copies. Nayak–Zhou, **NZ78**, [arXiv:2609.10514v1](https://arxiv.org/html/2609.10514v1), Theorems 1.1–1.2, give the small-error constant-confidence order \(\Theta(dr\epsilon^{-2}\max\{1,r/\sqrt t\})\) for rank-at-most-\(r\) states, with classical adaptation of successive joint measurements and no persistent quantum memory between them. These results constrain output measurement size. They cannot be read as the fresh-query \(b\) law, which permits unrestricted final joint processing. MB67 Section I.5's suggested blockwise Choi purification likewise concerns output-copy processing. These precedents prevent a claim to be the first resource interpolation for quantum learning.

## Growing-dimension binary lower bound and current channel-learning work

**Existing binary bounds.** MB67 Proposition IV.17 proves a projector-packing lower bound with \(\Omega(d^2)\) at fixed accuracy. Its Corollary IV.20 also proves
\[
 M=\Omega\bigl(d\epsilon^{-2}\log(d/\eta)\bigr)
\]
for operator-norm tomography of binary POVMs, \(0<\epsilon\le\epsilon_0\), \(0<\eta<1/4\), even with arbitrary adaptive quantum strategies. This second bound uses diagonal multi-coin effects. These are the actual binary conclusions of the checked source; separate bounds are not multiplied into an unstated theorem.

**Oufkir–Girardi, OG67.** [Version record](https://arxiv.org/abs/2601.04180v4), [full text](https://arxiv.org/html/2601.04180v4). The checked v4 is dated 16 January 2026. Theorem 4 (Section 3) gives the general-channel lower order \(\Omega(d_A d_B r/[\epsilon^2\log(d_Br/\epsilon)])\) when \(d_A\le rd_B/2\), at constant success probability, allowing fully coherent queries. The corresponding boundary order has \(\epsilon\) instead of \(\epsilon^2\) when \(d_A=rd_B\). Its hard families are general quantum channels, so setting \(d_B=2\) alone does not prove a binary classical-output statement.

**Chen–Zhang–Yu, CZY78.** [Version record](https://arxiv.org/abs/2601.10683v1), [full text](https://arxiv.org/html/2601.10683v1). Theorem 1.1, restating Theorem 4.2, proves the optimal order \(\Omega(rd_1d_2\epsilon^{-2})\) in the general-channel regime \(rd_2\ge2d_1\), with arbitrary coherent adaptive queries, for sufficiently small error and constant success. It removes OG67's logarithmic loss. The construction in Section 4, equations (17)–(18), retains quantum coherence between two output sectors. Consequently its stated general-channel lower bound is not used as a binary-qc theorem. Whether a suitable readout and restricted packing give an equivalent binary lower bound is an explicit priority question.

**Present binary argument.** **lem:weakmeasurementinfo78** directly treats effects near \(I/2\). For \(E_x=I/2+H_x\), \(\|H_x\|_{\rm op}\le r\), a query on any label-dependent input/reference state has conditional output branches \(\rho_R^x/2\pm\Delta_x\), with \(-r\rho_R^x\preceq\Delta_x\preceq r\rho_R^x\). Relative entropy against an independent fair output bit bounds the information added by that query by \(\log(1+4r^2)\le4r^2\), including arbitrary retained memory. An operator-norm packing of dimension \(d^2\), with radius of order \(\delta/\sqrt N\), gives **thm:dimensionlower78**:
\[
 M\ge c d^2N\delta^{-2}
\]
at constant confidence. The hard family lies in the promised interior. The theorem applies for every \(d,N\ge1\), \(0<\delta\le2^{-13}\), and \(0<\eta\le1/8\). It improves the manuscript's earlier scalar-only dimension comparison and, with the MB67 interior reanalysis, gives **thm:interiorlearning78**. The operator-loss specialization **cor:binaryoperatorlearning78** has \(0<\epsilon\le2^{-14}\) and failure at most \(1/8\). No priority claim is made for weak-channel information bounds, volumetric packing, Fano's inequality, or joint one-use dimension/accuracy scaling without comparison to equivalent channel results.

The full-body upper bound remains \(Cd^4(N^2/b)\delta^{-2}\log(d/\eta)\). Combining its block and dimension converses leaves a growing-dimensional gap; the sharp promised-interior theorem does not eliminate that gap on the whole effect body.

### Learning and discrimination resources retained from earlier revisions

**Bisio–D'Ariano–Perinotti–Sedlák (2011), BDPS76.** [Full text](https://arxiv.org/pdf/1103.0480v2), [published article](https://doi.org/10.1016/j.physleta.2011.08.002). Their learning and retrieval network stores information from an unknown von Neumann measurement in quantum memory and later reproduces a measurement on a new input. The paper optimizes training with one and two examples and identifies a nonparallel feature with three examples. That stored programme and retrieval criterion differ from the present high-probability classical estimate.

**Multiscale phase methods.** Higgins and collaborators (2009), HB76, [full text](https://arxiv.org/pdf/0809.3308v4), develop unambiguous phase estimation using increasing phase powers and controlled error probabilities. Kimmel–Low–Yoder (2015), KLY76, [corrected version](https://arxiv.org/pdf/1502.02677v3), extends the approach to robust gate calibration; its 2021 erratum corrects the phase-unwrapping analysis. Section 55 credits this background and proves its own safe-angle induction and conditional concentration bounds instead of importing the original numerical threshold.

Theorem 5 of Gutoski, Gutoski66, [full text](https://arxiv.org/pdf/1008.4636v4), gives a common discriminator for two convex sets of strategies. Repetition maps an effect nonlinearly to its \(N\)-use strategy, so convexity of the effect body does not ensure convexity of that image. A two-set discriminator is also not by itself a common estimator for an entire packing. The learning proof constructs its decision tree explicitly.

## The additional arbitrary-dimensional calibration and coding objects

The retained learning lemma **lem:matrixcalibration77** returns a legal \(A\) satisfying simultaneous multiplicative Loewner comparisons for both regularized support endpoints, together with \(\|E-A\|_{\rm op}\le N^{-1/2}\). It uses at most \(Cd^4N\log(d/\eta)\) product-input calls, including on unsuccessful records. **lem:matrixcompression77** uses the harmonic endpoint expression and the exact identity
\[
 (PEP)(I-PEP)
   =PE(I-E)P+PE(I-P)EP
\]
on the compressed space. The extra positive term is controlled at the \(N^{-1}\) cutoff because \(P\) commutes with the calibration estimate. This is the precise step permitting the qubit learner to be used inside an unknown matrix effect. The audit has not identified this calibration-and-compression statement in the cited one-use tomography theorems; independent assessment should compare equivalent regularized relative-error formulations as well as the final minimax law.

For **thm:matrixcodec77**, let
\[
 K=\left\lceil32dN/\delta\right\rceil.
\]
The algorithm enumerates a bounded coordinate grid, performs exact legality tests on both outcomes, and greedily retains a matrix when its squared \(Q_N\)-separation from every retained centre exceeds \((\delta/16)^2\). The squared comparison is rational and is obtained by solving a regularized Sylvester equation; spectral rounding thresholds are unnecessary. The proof uses the triangle inequality for \(d_N\) and the operational-ball volume theorem. It makes no triangle-inequality claim for \(Q_N\).

The ambient grid has at most
\[
 (K+1)^d(2K+1)^{d(d-1)}
\]
candidate tuples. This finite enumeration, exact rational centre selection, and deterministic decoder replay settle constructive existence with optimal-order index length. Their runtime and storage can be large. A physical unknown-device learner supplies observations; a supplied-description encoder receives a matrix or a certified approximation. Those inputs are different. Real-target coverage does not provide an oracle for exact coordinates; the finite encoder interface is stated separately. The implementation's completed small cases and matrix-kernel checks provide finite computational evidence, not a claim that large dictionaries have been fully enumerated.

Classical reconstruction, centre selection, and state preparation are excluded from the learner's device-call count and remain explicit resources. Public parameters determine the codebook; a nonpublic header must be charged. The priority question for the codec is the combination of this operational metric, the optimal-order dictionary size, and a terminating exact construction. Finite grid enumeration and packing arguments themselves are standard proof methods.

## Finite trusted controls and reproducibility boundary

Section 59, **thm:finitecontrollearning78**, transfers the common and block-restricted call orders to finitely described trusted preparations with certified trace error, and trusted controls with certified diamond error. **lem:controlhybrid78** sums the every-record trusted-instruction errors and bounds total variation of the entire classical output law. Running the ideal procedure at failure allowance \(\eta/2\) and distributing a further \(\eta/2\) allowance over the finite instruction count preserves the original risk target and exact legality of the returned effect. The argument includes discontinuous data decisions. It is an explicit use of the standard adaptive hybrid inequality, not a hardware-efficiency theorem. State-preparation time, workspace, and potentially exponential state descriptions remain charged separately from device calls.

## Version locators, search scope, and unresolved independent review

Current source checks in this audit specifically cover MB67 v3 (15 June 2026), ZRK76 v3 (9 July 2026), Hyllus78 v3, Toth78 v3, SHW68 v3, WBHK72 v2, OG67 v4 (16 January 2026), CZY78 v1 (15 January 2026), CLL78 v1, and NZ78 v1 (9 September 2026). The older discrimination/geometry comparisons above retain the exact source locators and caveats established in the preserved Revision 77 audit. The two main tomography versions were checked against arXiv's version records, and the ZRK76 journal record is *Quantum* **10** (2026), 2162. Bibliographic keys are inherited identifiers, rather than source revision numbers.

The search included primary-source queries about bounded entanglement depth, block-limited metrology, adaptive fresh-input channel discrimination, and recent channel and measurement tomography lower bounds. Stronger search was used to supplement routine lookup. This was a bounded author-side search, not a database-complete priority investigation. Unrelated search hits and abstracts without a checked relevant theorem are not used to infer a competing result. In particular, an output-side joint-measurement limit and an input-side fresh-block limit are kept distinct.

The new full-body block theorem, the positive interior reanalysis, the weak-binary dimension lower bound, and the finite-control transfer have concrete mathematical content for independent review. The pre-existing midpoint-resolvent comparison, endpoint-log entropy and exact codec remain separate priority objects. **INDEPENDENT_REVIEW_BRIEF.md** asks for a specialist to compare these exact statements, including equivalent reductions from current channel lower bounds. Review material has been prepared; independent human specialist judgment is pending. No outside reviewer has been contacted, no opinion has been supplied, and neither this audit nor the AI-assisted R51 report gives human priority clearance or a journal-level endorsement. The wider Theta A/B/C/D programme retains its separate unresolved status.
