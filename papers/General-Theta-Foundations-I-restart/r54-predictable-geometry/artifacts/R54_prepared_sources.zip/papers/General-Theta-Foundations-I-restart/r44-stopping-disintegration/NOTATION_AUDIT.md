# Notation audit

- `B`: physical mixture/test base; `D`: operating certificate domain; `K`: global acquired-output domain. None alone is asserted to be a particular acquired support.
- `u_0`: known preparation; `X_t`: true full-history predictive state, never a free finite-program register.
- `I_a^0,I_a^1`: raw continuing/stopped subinstruments; `L_a`: normalized unmarked core; `s_a`: report-dependent acceptance, `alpha`: common stopping scale. The action is selected before the report.
- `z`: actual pre-call live occupation; `a`: preparation injection; `y=Pz`: continuing arrivals; `d=Qz`: actual terminal ensemble.
- `q_s`: normalized live occupation, `q_j^+`: arrival mean, `r_j^*`: terminal mean. They are not interchangeable and are not asserted to be timewise conditional means.
- `g`: protected audit Bayes risk with full noise moment; `V_alpha`: all-history optimal risk for the same controlled hazard protocol.
- `nu_alpha^pi`: actual stopped predictive law; `q_M(nu)`: static squared quantization functional, not a programmed state vector.
- `M`: total dynamic observer labels; `m`: grid cells after preparation/halt charges; `R`: simulator states; program and workspace bits are separate.
- `N`: a declared expected raw budget, not a hard cap; `H`: auditor's hard cap, not an uncharged observer clock.
- `delta_out`: readout rounding; `delta`: truly invisible calibration alternative only in the attained task; `theta`: per-call coupling discrepancy; `epsilon`: complete stopped-law simulation error (attained a/2 only in the constructed bit interface).
- `d_j`: when subscripted in the singular section, stratum dimension; terminal ensemble `d` is distinguished by context and vector indices. Native prose never calls changing affine dimension a physical zero-eigenvalue transition.

All labels/citations/active inputs are machine-checked separately, but this semantic audit is not replaced by that check.
