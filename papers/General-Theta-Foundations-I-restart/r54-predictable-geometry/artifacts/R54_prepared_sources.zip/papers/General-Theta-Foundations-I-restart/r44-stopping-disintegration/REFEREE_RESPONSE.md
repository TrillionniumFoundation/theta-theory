# Response to the latest R32 external report

Dear Referee,

We thank you for the detailed distinction between correctness of the reviewed finite-affine theorem and its breadth and significance. The report reviewed `0982c854ddc20c2725f12f0fed67d61111776158`, with external report `65bd07d89b04274c587d2ae4100511d99c39b0f2`. The present revision also incorporates the later deposited R34–R43 work without pretending it had received a newer external review.

## Central mathematical response

The first new result is an exact, global, stopped finite-state realization criterion. It eliminates the report-routing kernels through their joint support function while retaining preparation injection, continued occupation, terminal occupation and one common program. Uniform transience proves that a feasible balance is the actual first run rather than an arbitrary stationary solution. This gives necessary and sufficient recursive feasibility and attainment in the declared finite-affine class; it does not claim a simple dimension-only characterization or efficient synthesis.

The second result is a source-aware exact regret identity for arbitrary homogeneous label reuse. It has action regret, a preparation-mixing Jensen defect, a continuing Jensen defect and terminal projection loss. The one-label positive-chain example has zero local routing defects but preparation loss exactly 9/350. Report-dependent stopping produces distinct live, arrival and terminal means; the selection example shows a 1/16 loss from the wrong mean.

For the quantitative consequence, stopping now has hazard alpha s_a(y), selected from a finite sensing/hazard library before the report. The functions may vanish on report regions. The full-history comparator optimizes every legal adaptive library policy. A preparation-injected common-grid observer has one counted initial label, separately calibrated terminal readouts, and matching M^{-2/d} excess uniformly as actual expected raw acquisition grows like alpha^{-1}. The mechanism is the product of an O(alpha) Bellman oscillation and O(alpha^{-1}) actual occupation mass. The earlier R43 independent-geometric preparation injection is credited explicitly, not reannounced as a new discovery.

Controlled Gaussian and noncommuting quantum instruments verify this same theorem, with accepted report regions and actual integrated hazard floors. Finite marked affine strata retain the true stopped masses. A fully specified three-label Gaussian program has exact normal-CDF/resolvent formulas, not a claimed numerical optimum. Calibration and attained deficiency are combined on one protected product task; numerical and simulator costs remain separately typed.

## Major comments 17.1–17.12

| Comment | Response and location |
|---|---|
| 17.1 precise class first | Abstract begins with known prepared positive experiments and finite separating executable affine tests; quantitative hypothesis hierarchy is explicit. The protocol is no longer merely passive fixed-horizon. |
| 17.2 identity versus sharp law | Sections 3–4 contain the density-free exact criterion/identity; Definition 5.1 and Theorem `thm:transfer` add mass, global cells, buffer, overlap and hazard certificates. |
| 17.3 all barycenters | Definition `def:regular` quantifies every incoming u in D, every action, before any table. Actual stopped rows are bounded by their original weighted occupation; acceptance example locates failure without a uniform hazard condition. |
| 17.4 local/global | The common support-function criterion is global. The preparation example with exact loss 9/350 is in the main text. Branch-blind and common-model max placement are explicit. |
| 17.5 value-directed compression | Section 11 compares task metric, information object, hard labels, adaptive library comparison and guarantee; adds Poupart–Boutilier 2000/2001/2002. |
| 17.6 Bregman context | Section 11 cites Varshney and identifies Jensen/Bregman geometry as standard; new contribution is stopped/source disintegration, not the convex inequality. |
| 17.7 current belief literature | Section 11 compares Kim 2026 and Díaz-Infante Velasco–Garcia–Minjárez-Sosa 2026, distinguishing input/output windows, finite observation partitions and hard controller labels. |
| 17.8 contrast stability routes | Appendix A gives exact rational curvature >6 with pathwise contraction <=49/50, and an idle-word example with integrated curvature <1 but no uniform pathwise block contraction. They are not falsely promoted to rate-class realizations. |
| 17.9 autonomous budget | Section 9 and the resource table distinguish one initial label, grid labels, duplicate internal halt labels and externally charged cap counter. The old fixed-deadline M-n curve is preserved in the complete companion, not incorrectly transferred to random stopping. |
| 17.10 concrete Gaussian | Section 10 gives primitive numbers, explicit domain/density/overlap/hazard constants, three exact routing thresholds, finite matrices, actual terminal weights/readouts, risk and acquisition formulas. Checkpoint comparison is exact as a variational identity plus explicit bounds; no unsupported optimum value is printed. |
| 17.11 quantum interpretation | The primitive is an unsharp positive-effect measurement followed by unitary feedback and a depolarizing channel, with a final IC audit. Both the effects and feedback may be noncommuting. No claim that a broadly recognized unsolved quantum benchmark has thereby been settled. |
| 17.12 editorial separation | Native proofs are self-contained. Complete old articles are archival companions and identified as such; build/test counts and repository workflow are absent from the mathematical introduction. |

## Requested significance directions and remaining questions

The revision addresses global recursive feasibility, adaptive acquisition, report-dependent stopping and changing marked support at theorem level. It does not claim that all broad directions in Section 19 of the report are closed. Unknown-kernel learning, generally nonsummable sensitivity with matching converse, arbitrary nondominated infinite-dimensional tests, efficient synthesis, and a matched program/workspace/time frontier remain distinct proof problems. The quantitative geometric certificates are sufficient, not proved necessary. The fixed hazard library does not represent all optimal stopping rules under only an expected-time constraint.

We retain the mother-problem title and the complete historical mathematics, while stating the achieved class in the first sentence. Whether the new results supply the required general-journal significance, and their correctness and priority, should be decided by independent review. Neither repository organization nor successful builds are offered as evidence of a mathematical breakthrough.
