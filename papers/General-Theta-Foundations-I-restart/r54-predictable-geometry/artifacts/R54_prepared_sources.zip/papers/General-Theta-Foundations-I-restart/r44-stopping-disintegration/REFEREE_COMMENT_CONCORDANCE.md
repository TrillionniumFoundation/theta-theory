# R32 technical comment concordance

The 12 major comments are answered in `REFEREE_RESPONSE.md`. All 32 technical comments below are accounted for; an inherited statement is not silently claimed as a newly proved broader theorem.

| R32 §18 | Issue | Disposition |
|---|---|---|
| 1 | Perspective numerator | The native stopped proof avoids this derivative notation; Appendix A has an explicit scalar derivative. The inherited R32 formula is retained unchanged, and no F(c v) expression is introduced. |
| 2 | Likelihood functional | Raw maps in Section 2 separate scalar likelihood and vector numerator; dual functionals are explicitly in E*. The audit second moment c is not a report-likelihood row. |
| 3 | Attained quotient versus mixture base | Section 2 separates live attained Borel image, compact mixture B, operating D and acquired-output K; terminal interface status is not identified solely by coordinates. |
| 4 | Common null sets | Section 2 requires raw affine identities simultaneously on the domain off actionwise reference-null sets. |
| 5 | Zero likelihood | Section 2 explicitly uses positivity and bounded coordinates to force zero unnormalized vector; zero branches are never normalized. |
| 6 | All legal histories | Uniform transience and hazard conditions quantify every full-history policy and incoming D state; no restriction to an exact filter trajectory. |
| 7 | Positive label paths / clock | The preserved fixed-deadline proof remains a companion theorem. New random-stop proof uses transient positive ensembles, and internal halt copies are explicitly counted; no borrowed deterministic clock argument. |
| 8 | Terminal codepoint count | Section 6 permits arbitrary off-support and repeated readouts; repeats cannot increase distinct centers. New random-stop budget is not M-n. |
| 9 | Loss of stability | Lemma bellman-span displays b/epsilon and 1/r; hazard eta_- and all raw constants are fixed, and the manuscript states degeneration can blow them up. |
| 10 | Stored response | Sections 2/6 attach fixed terminal readouts to labels; they are static program constants, not a retained exact posterior vector. |
| 11 | Gaussian temporal order | Theorem gaussian states report first, transition second, and the benchmark repeats it. |
| 12 | Gaussian determinant | The likelihood-rank matrix and transition determinants appear explicitly among fixed constants in the full-tail density proof. |
| 13 | Hilbert overlap mass | Native proof uses actual acquired overlap, not latent transition overlap. The inherited Hilbert route is preserved under its original restrictions; Appendix A quantitative scalar route is proved directly. |
| 14 | Quantum operator norm | Theorem quantum states ||H||op<=||H||HS; audit chart is an IC probability chart, not an unperformed simultaneous measurement. |
| 15 | Trace-D hyperplane | E_H=I+beta H has trace D because H is traceless; inverse effect is D B^2/tr(B^2). |
| 16 | Quantum constants | The proof lists positive floors, beta, lambda, finite quiet-word probability and inverse derivative controls; constants may deteriorate as lambda approaches one or beta approaches zero. |
| 17 | Initial interior domain | D and K+B_r are declared before the table, with u0 in D; raw output enters K from the first call. No free improving prelude is assumed. |
| 18 | Meaning of strata masses | Theorem strata distinguishes current raw mark w_j from actual terminal weight alpha E sum D_{a,j}1(X_t); the mark is not a persistent prior branch label. |
| 19 | Off-support centers | The relative-affine converse orthogonally projects arbitrary centers before union-of-balls. Earlier orbit-specific argument remains in its separate companion. |
| 20 | Allocation at fixed weights | Theorem strata uses fixed positive proportions and explicitly disclaims optimal allocation when weights vary with budget. |
| 21 | Simulator private coins | Proposition simulator includes fresh observer randomization in the complete stopped scored law and in the coupling. |
| 22 | Unconditional boundary mass | Proposition precision requires an actual conditional first-mismatch certificate and sums it against unconditional ideal survival probabilities. Boundary mass must be valid for true inputs, not just calibrated mean inputs. |
| 23 | Gaussian tails | The raw Gaussian theorem and explicit code integrate whole tails. Numeric classification errors require a separate certificate; no artificial tail truncation becomes a new physical observation. |
| 24 | Bit and core conditional independence | The new attained experiment postpones the bit report until core controls are frozen, so conditional independence is architectural. Earlier protocols are retained separately. |
| 25 | Bit loss scale | New product task uses a fair +/-1 bit with response in [-1,1]: erasure variance is a=2 epsilon; calibration alternatives contribute delta^2. |
| 26 | Checkpoint response conversion | The old checkpoint formula remains under its original bit protocol. New same-task extension uses posterior zero on erasure and explicit loss a, without reusing an incompatible (1-a)b response. |
| 27 | Small integer budgets | Internal halt uses 1+2m<=M with m=floor((M-1)/2), M>=3. Product task uses 4m+2 sufficient and sufficiently large M; no unproved exact small-budget minimum. |
| 28 | Dimension and loss normalization | L in the task and all simulation/precision bounds retains the audit norm; constants may depend on the fixed physical dimension. |
| 29 | Legal-observer quantifier | Native claims say homogeneous Borel observers and all full-history policies of the finite sensing/hazard library; arbitrary stopping or unknown learning is excluded explicitly. |
| 30 | Bibliographic metadata | References supply years and DOI or arXiv where available; UAI/NIPS papers without DOI have precise proceedings/pages and primary-source metadata. |
| 31 | Build counts out of math | Only build/audit evidence contains counts. The mathematical introduction has none. |
| 32 | Lineage distinction | SOURCE_LINEAGE preserves original R27, corrected F, reviewed R29, R32, and later R34/R37/R38/R43 as separate sources; no overwrite or synthetic renumbering. |
