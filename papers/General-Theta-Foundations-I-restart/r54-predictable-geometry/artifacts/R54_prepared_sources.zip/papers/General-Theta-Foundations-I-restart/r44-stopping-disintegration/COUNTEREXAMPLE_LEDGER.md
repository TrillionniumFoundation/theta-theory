# Counterexamples and sharpness witnesses

1. **Preparation mixing** (`ex:preparation`): strictly positive two-state transition, one uninformative report, geometric hazard 1/2, preparation zero. One label has live mean 3/10, terminal mean 3/5, risk 6/25 versus 3/14; local routing/action defects vanish but preparation defect is exactly 9/350. This blocks source-free local criteria, not the research objective.
2. **Stop selection** (`ex:selection`): fresh fair bit, accuracy 3/4, stop rates 3/4 and 1/4 by report. Continuing mean 3/8 versus terminal 5/8; wrong-centroid squared excess 1/16.
3. **Unrestricted acceptance** (`rem:selection-lower`): uniform [-1,1], accept |X|<=h; E tau=1/h and one-label risk h^2/3. Ordinary raw-row dimension does not determine selected terminal mass.
4. **Mark-blind routing** (`rem:branch-blind`): with opposite preferred labels on the two marks, a sum of maxima is larger than a maximum of their sum. The latter is required for a common pre-mark routing kernel.
5. **Common unknown models** (`cor:common-model`): put model sum inside label max; separate modelwise maxima allow different programs and are not a uniform simulator.
6. **Curvature vs pathwise** (`prop:CnotP`): rational one-step curvature >6 while log-odds contraction <=49/50. This rejects that envelope, not every localized curvature route.
7. **Pathwise vs curvature** (`prop:PnotC`): positive-probability idle words are identity maps but integrated half-Hessian is omega I, omega<1. Discrete example is not falsely promoted to the density-rate class.
8. **Finite Gaussian program** (`prop:benchmark`): exact normal-CDF/resolvent formulas for three labels under report-selected stopping, not a numerical optimum or proof of a continuum rate.
9. **Coincident lower terms** (`cor:attained`): core quantization, invisible calibration and actual bit erasure live on one product task; 4m+2 is sufficient, no small-budget minimum claimed.
