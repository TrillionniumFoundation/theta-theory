# Scope audit against F1–F4

F1: exact global recursive finite-state criterion from marked raw instruments and uniform transience; matching actual acquired-density/global-cell rates require declared buffer and feedback-overlap certificates. Both checkpoint and counted homogeneous implementations are proved. Internal halt copies are paid.

F2: actual expected raw acquisition, persistent labels, program constants, workspace, cap counter, terminal precision and parameter-independent simulator states are distinct coordinates. The single-task extension attains M-rate + delta^2 + epsilon; general tolerance upper bounds do not imply those lower terms. The dynamic baseline V_alpha depends on the stopped experiment and is not a static unknown-parameter learning law.

F3: fixed finite marked affine components, atoms and differing acquired dimensions are treated with actual stop-dependent weights and full relative proofs. Arbitrary singular degenerations are not claimed. Mark support may change on report regions even when the unmarked core likelihood is positive.

F4: controlled Gaussian sensors and genuinely noncommuting positive quantum instruments each verify the same center theorem from raw kernels. The singular quantum marked family is a further realization, not a premise of foundations.

The paper remains General Theta Foundations I. It does not become a survey, roadmap, definition list or realization-only paper. The central finite-affine stopped class is explicit. Top-four importance and novelty must be independently evaluated; repository operations are not described as mathematical breakthroughs.
