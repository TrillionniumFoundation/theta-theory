# Assumption matrix

| Input / quantifier | Exact realization | Matching law | Raw verification / boundary |
|---|---|---|---|
| Known standard-Borel experiment; finite actions; live/terminal interfaces | Required | Required | Gaussian/quantum actions before report; no inaccessible true parameter |
| Separating finite executable affine closure with Borel sections | Required | Required | categorical / informationally complete protected audit; not positivity alone |
| Positive integrable marked maps on operating cone, shared null sets | Required; marks may have zeros | Core likelihood positive; mark may vanish | region-selected stop supported only on part of report space |
| Uniform transience for every legal feedback strategy | Required, block form allowed | Derived from integrated hazard floor | every input, not just calibrated rows |
| One common routing program for incoming ensembles | Necessary and sufficient support inequality | Satisfied by common grid | max location changes if routing precedes mark / is shared across models |
| Actual-row density upper on all declared incoming means | Not required | Required | whole Gaussian simplex; positive congruence Jacobian |
| Global convex cover and null row boundaries | Not required | Required | entire declared K, not stationary/reachable subset |
| Buffer K+B_r within D | Not required | Required | controls nonsmooth Bellman Lipschitz norm |
| Feedback-uniform acquired overlap | Not required | Required | actual report overlap; not observer mixing or free reset |
| Report kernel continuity | Needed for specified continuity uses | Explicit TV and weak continuity | raw likelihood bounds |
| Integrated hazard eta_- <= D_a1 <= eta_+ | General transience suffices | Required uniformly in action and D | s_a(y) itself may be zero |
| Actual component masses and relative densities | Not required | Singular extension | preserve stopped mass formula; no unit-mass normalization |
| Effective integration / legal readout nets / boundary moduli | Not a Borel existence assumption | Only finite-bit/compiler claim | arbitrary real constants are not automatically computable |

The library of sensing/hazard actions is fixed before choosing alpha, M and a program. The scale alpha may depend on the declared expected acquisition budget. Rates compare policies in this same interface; unrestricted acceptance rules are a different experiment. All constants in the uniform rate may depend on the fixed experiment and diverge when its certificates degenerate.
