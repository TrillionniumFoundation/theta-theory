# Build and verification

Requirements: Python 3, numpy, pypdf, pdflatex (AMS and Latin Modern packages), pdfinfo, pdftotext. No shell escape is used. Scripts use explicit checks, not assertions disabled by python -O.

Native source/label/citation inventory:
`python verify.py`

Finite regression in both modes:
`python regression.py`
`python -O regression.py`

Two isolated native builds, three LaTeX passes each:
`python native_build.py --source-sha FULL_SOURCE_SHA --expected-tree ORDINARY_PROJECTION_TREE --output /tmp/native --receipt /tmp/native.json`

Native plus full R43 and the complete retained R38 chain:
`python build.py --source-sha FULL_SOURCE_SHA --expected-tree ORDINARY_PROJECTION_TREE --output /tmp/full --receipt /tmp/full.json`

Source projection is independent of artifacts/evidence/review-input/transport directories; all ordinary files are listed with SHA256 and Git blob identity in SOURCE_MANIFEST.json. The report is independently pinned by Git blob. Actual TeX recorder inputs must match the declared active input graph; undefined references, duplicated labels, unused bibliography and overfull boxes fail the native build.

The publisher first deposits ordinary native R44 and unchanged decoded R43 source, then binds the build to that commit. It creates a distinct artifact commit. Independent verification must start from the actual remotely downloaded source/artifact packet and leave it byte-identical; final evidence is a third commit. Visual inspection and any cross-engine differences are recorded precisely, without claiming byte equality across different TeX engines when not true.

The complete companion chain is rebuilt, not all papers in the repository or v1–v96. Finite tests and successful builds are not proofs of continuum theorems or novelty.
