# Source lineage and immutable inputs

Canonical branch: `foundation/general-theta-foundations-i-restart-2026-10-06`.
Canonical commit: `18000b21e4bfd89180ccb069e46ac0f21621f34d`.
Latest discovered external restart review: `65bd07d89b04274c587d2ae4100511d99c39b0f2` (R32).
Review blob: `3731f79996e11cdac66ce7c8a3ee5fdf1fffcd21`.
Latest prior completed referee-ready head: `0982c854ddc20c2725f12f0fed67d61111776158` (R32).
Latest later completed ordinary-source/artifact pair discovered: R38 `159f92128d690221395fd550b186af6abdc5f6ba` / `616f35afcafddda1c3166568be8c77c7ea424fb9`.
R43 deposited source transport/bootstrap: `1909092aeccc74b227fb568eafad6e958efb62d5`.
R43 transport SHA256: `f85c3b2593bf540249f17be442b815a2ea0c190c77d56fb495181b40524e8e30`.
R43 decoded ordinary-source projection: `bdbbac591826cff47200a6e0601dcdd48e5400c9`.

The new research branch was created at canonical. Its first substantive intake commit `a37aed9cb20b7eb16560acc9c18cc0bfddcdf565` has canonical as first parent and R43 bootstrap as second parent. No old branch was advanced. R43's 35 deposited ordinary text files were recovered by exact Git blob and SHA256 checks in the read-only export run `38236584993`, input artifact `11741650654`. This is an input extraction receipt, not a mathematical or PDF-build certificate.

The decoded R43 files are deposited unchanged as ordinary files on the new branch, with the original review inputs retained; its original source-labelled branch is not overwritten. The new R44 main is authored separately. The entire inherited repository tree is preserved. Four control blobs and old R4–R38 mathematical trees are checked by their Git identity in publication receipts. Original R27, corrected Companion F, reviewed R29, R32, R34, R37, R38 and R43 remain separately named sources. No v1–v96 source, review, realization or frozen archive is deleted or relabelled.

Ordinary source, build artifacts and final read-only evidence are distinct commits. Their exact final SHA values belong in generated evidence; no source file contains a self-referential final SHA. A source projection excludes artifacts/evidence, input transport and pinned external review copies; the actual complete native Git tree is recorded separately.
