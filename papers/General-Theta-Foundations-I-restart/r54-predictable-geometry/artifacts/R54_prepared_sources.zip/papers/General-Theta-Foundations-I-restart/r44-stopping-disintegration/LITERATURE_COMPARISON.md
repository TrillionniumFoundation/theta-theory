# Primary-literature comparison

Verified 12 October 2026, using primary publisher/author/arXiv records.

- Dufour–Prieto-Rumeau, *Absorbing Markov decision processes*, ESAIM COCV 30 (2024), 5, DOI 10.1051/cocv/2024002 / arXiv:2309.07059: characteristic equations can have nonoccupation solutions. This is the relevant precedent for the source/resolvent identification, not an omitted novelty competitor.
- Dufour–Prieto-Rumeau, *Absorbing Markov Decision Processes and Their Occupation Measures*, SICON 63(1) (2025), 676–698, DOI 10.1137/24M1661959: uniform absorption and compactness require hypotheses. We give an explicit finite-cone uniform-transience proof, not an assertion that all occupation sets are compact.
- Poupart–Boutilier, UAI 2000, 497–506, and UAI 2001, 445–452: value-directed belief-state approximation and vector-space analysis are also cited in the article; their task-sensitive compression precedes this work.
- Poupart–Boutilier, NIPS 15 (2002), 1547–1554, *Value-directed compression of POMDPs*: decision-quality-aware compression is established prior work. Our comparison concerns hard labels, common routing, first-run source flow and report-selected terminal measures.
- Varshney, IEEE TSP 59 (2011), 4470–4472, DOI 10.1109/TSP.2011.2159500: Bayes-risk/Bregman geometry is standard; the novelty claim is not Jensen's inequality.
- Borkar–Mitter–Tatikonda 2001, Yu–Bertsekas 2008, Saldi–Yuksel–Linder 2016, Demirci–Kara–Yuksel 2024: sequential quantization, finite-state control, finite approximations and average-cost stability are direct antecedents.
- Mintae Kim, arXiv:2601.03132v1 (2026), read in primary HTML: the fixed-policy finite input/output-window belief comparison is not automatically a hard-cardinality-label or unrestricted adaptive-policy comparison. Do not describe it as the identical theorem or dismiss it as unrelated.

- Díaz-Infante Velasco–Garcia–Minjárez-Sosa, arXiv:2608.13825 (2026): the primary abstract describes normalized filtering and control under finite partition-based observations, with atomic and continuous components. We checked its abstract rather than claiming a full proof audit. Report-partition size is not the same resource as the complete finite observer/controller state count. The comparison in the article is limited to that declared scope.

The main text cites the inherited General Theta Bayesian, controlled, finite-acquisition and independent-geometric-stop articles explicitly. R43's raw Gaussian constants, quantum inverse/quiet-word mechanism and preparation injection are inherited, not newly claimed in R44. R44 adds marked terminal selection, arbitrary-label source defects, the exact global support criterion and its effective stopped realization.

This comparison is not an exhaustive priority search and does not establish journal acceptance.
