# Resource accounting

| Coordinate | Exact treatment |
|---|---|
| Actual raw acquisition | tau; E tau in [1/(alpha eta_+),1/(alpha eta_-)] for every legal policy |
| Expected budget N | alpha=1/(eta_- N), N>=1/eta_-, ensures E tau<=N and E tau>=eta_- N/eta_+; comparator retains this hazard protocol |
| Preparation / protected audit | one each, separately physical: tau+2 calls |
| Homogeneous external-mark observer | 1 exclusive preparation label + m grid labels; total M=m+1 |
| Internal halt | 1+2m labels, halt status stored, no hidden phase register |
| Terminal vs continuing constants | two different read-only program vectors may be attached to the same dynamic label; counted in program bits |
| Deterministic cap H | external auditor counter; physical max H+2; NOT a free internal clock theorem |
| Checkpoint | M terminal labels; preceding full history/workspace not counted as M |
| Program description | at least explicit action/routing/continuing/terminal lists in the implementation model; vector lists <=2dMb bits at precision b, routing may cost O(M^2|A|Jb) |
| Workspace | temporary report, arithmetic and classification registers separately charged and cleared before next call |
| Fresh randomization | no retained seed; all randomization present in complete joint coupling |
| Numerical errors | per-call coupling accumulated against actual survival; terminal centroid rounding quadratic for fixed ideal program |
| Simulation | target M times simulator R dynamic state pairs; serial errors add; clocks/actions/readouts matched |
| Same-task bit extension | controls frozen after core stop; one extra paid bit report then common audit; E calls=E tau+3; 4m+2 labels sufficient, not minimal |
| Execution / planning time | explicit primitive and enumeration costs required; no matched global optimum claimed |

A finite expected call count is not a hard cap or an almost-sure time bound. Precision, calibration alternatives and deficiency upper bounds are not interchangeable lower-bound parameters. Exact rates apply to the stated known experiment, not to an observer supplied with the true unknown parameter.
