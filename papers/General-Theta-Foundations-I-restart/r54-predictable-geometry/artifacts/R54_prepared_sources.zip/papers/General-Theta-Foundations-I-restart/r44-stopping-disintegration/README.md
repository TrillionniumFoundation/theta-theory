# General Theta Foundations I — stopping disintegration

Native restart R44: a new self-contained foundations source, not a realization renamed as a foundations theorem. Editorial date: 12 October 2026.

The current manuscript is `main.tex`. It characterizes first-run stopped finite-state realizability by a positive dual inequality, separates preparation/continuing/terminal defects, and proves matching checkpoint and homogeneous-state curves for controlled report-dependent stopping. The quantitative result assumes explicit actual-mass, global-cover, buffer, hazard and acquired-feedback-overlap certificates. It optimizes all legal full-history choices from the specified sensing/hazard library, not arbitrary stopping rules constrained only by their mean.

## New mathematics and inheritance

New: the marked stopped-occupation common-routing criterion and attainment; the preparation-sensitive four-term identity for arbitrary label reuse; live/arrival/terminal disintegration under report-selected stopping; uniform matched geometric consequences with an integrated rather than pointwise hazard floor; fixed-label effective approximation by the transient ensemble maps.

Inherited and explicitly cited: finite executable affine realization, conditional projection and positive perspectives, mass–curvature geometry, raw Gaussian/quantum calculations, and R43's preparation-injected construction for independent geometric stopping. They are reproved where needed for a standalone native argument; not claimed as newly discovered here. Full R43 is retained as Companion L, full R38 as K, and the complete earlier companion chain is retained.

## Mathematical entry points

- `thm:disintegration`: exact global stopped realization and optimal risk.
- `thm:identity`: action + preparation + continuing + terminal decomposition.
- `thm:transfer`: uniform matching law; `lem:injected` identifies actual first runs.
- `thm:gaussian`, `thm:quantum`: two raw instrument classes satisfying the same theorem.
- `thm:strata`, `cor:quantum-strata`: real weighted affine singular components.
- `prop:precision`, `prop:simulator`, `prop:effective`, `cor:attained`: distinct error and resource coordinates.

The precise quantifiers and proofs are in the manuscript. `REFEREE_RESPONSE.md` and `REFEREE_COMMENT_CONCORDANCE.md` address the pinned R32 external report. An exact criterion is not an efficient algorithm, and no universal classification, unknown-kernel learning or joint program/workspace/time optimum is claimed. Build status and commit roles are recorded only in final evidence, not inferred from this README.
