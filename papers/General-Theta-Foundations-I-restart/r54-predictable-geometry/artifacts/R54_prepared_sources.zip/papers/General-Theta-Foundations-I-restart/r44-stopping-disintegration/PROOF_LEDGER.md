# Proof ledger

| Statement | Essential proof | Status / dependencies |
|---|---|---|
| lem:quotient | separating executable coordinates, Borel-section factorization | proved in stated finite-affine section category |
| thm:disintegration | weak-star compact routing image + exact support function + transient positive resolvent | new global stopped criterion; density-free, not efficient synthesis |
| cor:common-model | joint model image, sum inside max, common readout | finite families only; not learning |
| thm:identity | actual unnormalized time disintegration and perspective algebra | new preparation/continuing/terminal split; exact for arbitrary homogeneous label reuse |
| lem:bellman-span | killed Bellman contraction and acquired-overlap span bound | generalization of inherited independent-stop mechanism |
| lem:mass-curvature | convex extension, positive distributional Laplacian, actual density | inherited geometric tool restated with proof |
| lem:injected | common-cell Kakutani with actual stop flux + first-run resolvent | marked extension of inherited preparation injection |
| thm:transfer | O(alpha) curvature times O(alpha^-1) actual mass; terminal quantization; all-policy acquired density lower | matching conditional resource law, not arbitrary optimal stopping |
| thm:gaussian | full log-odds Gaussian tails, Jacobians, common actual submass and accepted-region hazard | raw realization of same general theorem |
| thm:quantum | normalized positive congruence inverse, quiet report words, acquired common overlap | independent noncommuting realization |
| thm:strata / cor:quantum-strata | relative cells and actual stop-weight disintegration; positive raw conditional expectations | finite fixed marked family; predictive dimension not physical rank |
| cor:internal-halt / cor:cap | state duplication / whole-path coupling with explicit tail | separate resource architectures |
| prop:precision / prop:simulator | first mismatch over true surviving law / causal state product | complete stopped scoring; no TV-to-LDP inference |
| prop:effective | weighted simple routing approximation, uniform resolvent continuity, certified enumeration | added explicit computational certificates; no efficient/minimal frontier |
| cor:attained | one product task, conditional residual variance, parameter-independent early commitment | matching calibration/deficiency actually realized, not tolerance lower bounds |
| prop:benchmark | exact normal-CDF finite matrices and positive resolvent | a concrete code, not its global optimality |
| prop:CnotP / prop:PnotC | exact rational curvature; idle word argument | certificate contrasts only |

Finite regression, source audit, compilation and visual checks are not included as dependencies of any theorem.
