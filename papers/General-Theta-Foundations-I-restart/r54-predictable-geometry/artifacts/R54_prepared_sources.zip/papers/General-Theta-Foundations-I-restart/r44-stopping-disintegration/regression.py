#!/usr/bin/env python3
"""Exact finite identities and a Gaussian formula check; never a continuum proof."""
from __future__ import annotations
from fractions import Fraction as F
import itertools,json,math
COUNT=0

def check(condition:bool,message:str)->None:
    global COUNT
    COUNT+=1
    if not condition:raise RuntimeError(message)

def matvec(A,x):return [sum((a*b for a,b in zip(row,x)),F(0)) for row in A]
def solve(A,b):
    n=len(b); a=[list(row)+[v] for row,v in zip(A,b)]
    for j in range(n):
        k=next((k for k in range(j,n) if a[k][j]),None)
        if k is None:raise RuntimeError('singular exact system')
        a[j],a[k]=a[k],a[j];pivot=a[j][j];a[j]=[v/pivot for v in a[j]]
        for k in range(n):
            if k!=j:
                ratio=a[k][j]
                a[k]=[v-ratio*w for v,w in zip(a[k],a[j])]
    return [row[-1] for row in a]

def finite_defects():
    routes=[[[F(1),F(0)],[F(0),F(1)]],[[F(0),F(1)],[F(1),F(0)]],
            [[F(1,2),F(1,2)],[F(1,2),F(1,2)]],
            [[F(1,3),F(3,4)],[F(2,3),F(1,4)]]]
    cases=0
    for a,alpha,u0,G,H in itertools.product([F(1,4),F(3,4)],[F(1,5),F(1,2),F(1)],[F(0),F(1,3)],routes,routes):
        n=4; p=[[1-a,a],[a,1-a]]
        P=[[F(0) for _ in range(n)] for _ in range(n)];Q=[[F(0) for _ in range(n)] for _ in range(n)]
        for j,s,i,k in itertools.product(range(2),repeat=4):
            P[2*j+i][2*s+k]=(1-alpha)*G[j][s]*p[i][k]
            Q[2*j+i][2*s+k]=alpha*H[j][s]*p[i][k]
        source=[1-u0,u0,F(0),F(0)]
        z=solve([[F(i==j)-P[i][j] for j in range(n)] for i in range(n)],source)
        d=matvec(Q,z);y=matvec(P,z)
        check(z==[aa+yy for aa,yy in zip(source,y)],'source balance')
        check(sum(d)==1 and sum(z)==1/alpha,'actual mass and acquisition')
        check(min(z+d+y)>=0,'positive occupation')
        r=1-2*a; c=alpha*r*r/(1-(1-alpha)*r*r)
        V=lambda x:F(1,4)-c*(x-F(1,2))**2
        g=lambda x:x*(1-x)
        def mean(v,j):return v[2*j+1]/sum(v[2*j:2*j+2]) if sum(v[2*j:2*j+2]) else F(0)
        def perspective(v,j,f):return sum(v[2*j:2*j+2])*f(mean(v,j)) if sum(v[2*j:2*j+2]) else F(0)
        risk=sum(perspective(d,j,g) for j in range(2))
        prep=sum(perspective(z,j,V)-perspective(y,j,V) for j in range(2))-V(u0)
        cont=sum(perspective(y,j,V) for j in range(2));term=F(0)
        for s in range(2):
            mass=sum(z[2*s:2*s+2]); q=mean(z,s); w=a+r*q
            for j in range(2):
                cont-=(1-alpha)*mass*G[j][s]*V(w)
                term+=alpha*mass*H[j][s]*(w-mean(d,j))**2
        check(risk-V(u0)==prep+cont+term,'four-defect algebra')
        check(min(prep,cont,term)>=0,'nonnegative defects')
        cases+=1
    return cases

def witnesses():
    V=lambda u:F(1,4)-(u-F(1,2))**2/7
    defect=2*V(F(3,10))-V(0)-V(F(3,5))
    check(defect==F(9,350),'preparation witness')
    check(F(6,25)-F(3,14)==defect,'preparation risk')
    check((F(5,8)-F(3,8))**2==F(1,16),'selection witness')
    # The interface changes a sum of maxima to a maximum of sums.
    u=[F(1),F(0)];v=[F(0),F(1)]
    independent=(max(u)+max(v))/2
    common=max((x+y)/2 for x,y in zip(u,v))
    check(independent==1 and common==F(1,2),'branch-blind support function')
    for k in range(17):
        t=F(k,16)
        check(t/2+(1-t)/2==common,'every shared routing respects support')
    p=F(1,100);r=F(49,50)
    pairs=[(F(1,200),F(1,2)),(F(199,200),F(1,2))]
    curvature=r*r*sum((f0*f1)**2/((1-p)*f0+p*f1)**3 for f0,f1 in pairs)
    check(curvature==F(387792606414808000000,61181567631019341199),'curvature rational')
    check(curvature>6 and r<1,'distinct stability routes')
    for alpha,eta in itertools.product([F(1,8),F(1,2),F(1)],[F(1,3),F(2,3),F(1)]):
        for H in (1,2,8,32):
            q=1-alpha*eta
            tail=q**H
            expected=sum(q**t for t in range(H))
            check(expected==(1-tail)/(alpha*eta),'finite stopped occupation mass')
            check(expected<=1/(alpha*eta),'cap cost')
    for M in range(3,65):
        m=(M-1)//2;check(1+2*m<=M and m>=1,'internal halting labels')
    return {'preparation_defect':'9/350','stopping_centroid_error':'1/16','curvature_envelope':str(curvature)}

def gaussian():
    Phi=lambda x:.5*(1+math.erf(x/math.sqrt(2)))
    prob=lambda lo,hi,mu:max(0.,Phi(hi-mu)-Phi(lo-mu)) if hi>lo else 0.
    import numpy as np
    C=np.zeros((6,6));Q=np.zeros((4,6));P=np.array([[.75,.25],[.25,.75]])
    for s,q in enumerate([.5,.375,.625]):
        threshold=-.5*math.log(q/(1-q))
        for j,(lo,hi) in enumerate([(-math.inf,threshold),(threshold,math.inf)]):
            allp=np.array([prob(lo,hi,mu) for mu in (-1,1)])
            stop=.5*np.array([prob(max(lo,0),hi,mu) for mu in (-1,1)])
            C[2*(j+1):2*(j+2),2*s:2*s+2]=P@np.diag(allp-stop)
            Q[2*j:2*j+2,2*s:2*s+2]=P@np.diag(stop)
    source=np.zeros(6);source[:2]=.5
    z=np.linalg.solve(np.eye(6)-C,source);d=Q@z
    weights=d.reshape(2,2).sum(1);readouts=d.reshape(2,2)[:,1]/weights
    risk=sum(weights*readouts*(1-readouts))
    check(float(np.max(np.abs(C.sum(0)+Q.sum(0)-1)))<1e-14,'Gaussian raw normalization')
    check(float(np.max(np.abs(z-source-C@z)))<1e-14,'Gaussian first-run balance')
    check(abs(sum(d)-1)<1e-14 and min(z)>=0,'Gaussian terminal mass')
    check(abs(sum(z)-4.411179195803749)<1e-12,'Gaussian expected count illustration')
    check(abs(risk-.22371410519416335)<1e-12,'Gaussian risk illustration')
    check(max(abs(readouts-z.reshape(3,2)[1:,1]/z.reshape(3,2)[1:].sum(1)))>.1,'separate Gaussian centroids')
    B=math.log(7)+2
    return {'expected_raw_calls':round(float(sum(z)),12),'risk':round(float(risk),12),
            'terminal_weights':[round(float(x),12) for x in weights],
            'terminal_readouts':[round(float(x),12) for x in readouts],
            'density_upper':round(4*math.exp(B+2)/math.sqrt(2*math.pi),12),
            'overlap_mass':round(math.exp(-(math.log(3)+B)**2/8)/math.sqrt(2*math.pi),12),
            'classification':'floating-point evaluation of exact Gaussian formulas, not an interval proof'}

def main():
    cases=finite_defects();w=witnesses();num=gaussian()
    print(json.dumps({'status':'PASS','finite_checks':COUNT,'exact_routed_cases':cases,
        'witnesses':w,'gaussian':num,'limitations':'Finite arithmetic and numerical formula checks do not prove continuum theorems, priority or journal importance.'},sort_keys=True,indent=2))
if __name__=='__main__':main()
