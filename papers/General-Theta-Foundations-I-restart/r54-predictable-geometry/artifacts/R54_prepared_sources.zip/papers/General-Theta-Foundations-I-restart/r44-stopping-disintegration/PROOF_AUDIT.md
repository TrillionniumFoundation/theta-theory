# Proof audit and remaining mathematical questions

Audit checks performed on the written argument:
- Quantifier order: common program, finite action library, known preparation, all legal full-history feedback comparators; not a separately optimized program for each hidden parameter.
- Live/terminal interfaces and conditional means separated. The full-history predictive variable is not supplied as a free register.
- Common reference-null sets; zero likelihood has zero unnormalized vector; no division at zero mass.
- Uniform transience proves finite occupation, resolvent identification and Bellman tail convergence; no fixed-time identity promoted to unbounded stopping by notation.
- Weak-star image has integrable coordinate functions and finite output dimension. Each support maximum corresponds to allowed report/mark timing.
- Global source injection preserved in balance and regret. Zero rows vanish uniformly; Bellman ties use simplex-valued correspondence, not an unjustified continuous selector.
- Density and grid requirements hold for all declared incoming barycenters, including counterfactual programmed states. Actual terminal measure is summed with its true survival and hazard mass.
- Uniform alpha cancellation uses Bellman oscillation O(alpha) and actual occupation O(alpha^-1); no assumed stationary observer law or uniform observer mixing.
- Gaussian likelihood-rank determinants and whole tails retained. Quantum effect hyperplane, inverse map, spectral floors, feedback quiet-word probability and audit chart are explicit.
- Singular weights are actual marked probabilities and their actual terminal transforms. Affine acquired rank is not physical eigenvalue rank.
- Numerical classification requires unconditional actual boundary mass; discrete-vs-continuous raw TV is not presumed small. Nontermination has an explicit bounded failure outcome or a termination guarantee.
- Precision, calibration alternatives and deficiency are distinct. Simulation preserves clocks/actions/report/readout and complete scored law; state budgets multiply.

Completed here: the exact finite-affine uniformly transient stopped criterion and its proofs; the matched controlled report-selected stopping law under the stated raw geometric certificates; the two raw verifications and finite marked singular extension.

Not established here: a necessary scalar dimension/stability classification for arbitrary raw kernels; general optimal stopping under only an expected-time constraint; unknown-kernel learning or regret; arbitrary infinite/nondominated predictive realizations; degeneration-uniform rates when hazard/overlap/rank certificates fail; efficient synthesis; optimal joint program/workspace/physical-time/simulator-state lower frontiers. The exact dual criterion is not marketed as an efficient solution to these problems.

This audit is an author-side proof review, not an external correctness, priority or journal-acceptance certificate. The referee should especially scrutinize support-image sufficiency, source disintegration, Kakutani graph closure, the alpha cancellation and raw quantum overlap.
