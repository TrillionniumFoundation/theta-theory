# Pipeline derivation: source-aware stopped disintegration

1. Begin with prepared positive marked instruments. Fix live versus terminal action interfaces and executable separating tests. Mixture coordinates are a representation, not an acquired distribution.
2. Sum unnormalized raw vectors over actual live histories. This yields z=a+Pz and d=Qz. Never commute normalized posterior updates with time averaging.
3. Eliminate report routing by the compact weak-star image of probability kernels. Its exact support function places the maximum where the physical timing permits it. Enforce all incoming ensembles jointly.
4. Use uniform transience to identify (I-P)^(-1)a as the first-run occupation. Without identification, formal flow can carry extraneous invariant mass. The terminal ensemble Qz is a different object.
5. Form the stopped Bellman value for all full-history library policies. Decompose finite-program regret into action, preparation mixing, continuing Jensen and terminal projection errors. The source-mixing counterexample proves why the extra term cannot be discarded for arbitrary label reuse.
6. For the quantitative class, the core acquired overlap bounds the killed Bellman oscillation by O(alpha), without observer minorization. The report-selected continuing occupation has mass O(alpha^-1).
7. Calibrate a common grid by injecting the actual preparation with the actual total stopping flux. Kakutani supplies a finite table; the resolvent identifies it with the actual first run. The exclusive preparation label annihilates source mixing. Compute terminal readouts from the separately stopped pushforward.
8. Multiply actual mass and nonsmooth curvature to cancel alpha. Terminal total mass is one and cells have squared diameter O(M^-2/d). This gives a fully counted homogeneous upper with no stationary entrance remainder.
9. Sum actual stopped rows under every legal full-history strategy to obtain the terminal density bound Lambda/eta_-. Union-of-balls gives the all-decoder lower, and conditional projection gives exact checkpoint quantization. Nothing uses ambient formal dimension without this actual mass proof.
10. Verify raw Gaussian and noncommuting quantum instruments independently; then project marked components while retaining their real stopping weights. Expected acquisition, internal halt, hard cap, calibration, numerical implementation and causal deficiency are separate steps with separate cost semantics.

This is a theorem-level extension of R43's independent-geometric stopped calibration, not a claim that its mechanism was newly discovered in R44. The main source gives complete proofs; this derivation is a navigation record rather than a substitute.
