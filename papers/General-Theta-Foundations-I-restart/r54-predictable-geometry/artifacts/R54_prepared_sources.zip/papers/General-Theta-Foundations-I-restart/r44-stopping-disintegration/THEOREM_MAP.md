# Theorem dependency graph

Stable labels are resolved to printed numbers in `NATIVE_BUILD_RECEIPT.json`.

```
raw prepared kernels + executable affine closure
                  |
             lem:quotient
                  |
  marked positive instrument + uniform transience
          /                               thm:disintegration                  stopped Bellman value
          |                              |
 exact finite-state value           thm:identity
          |                              |
          |          raw overlap -> lem:bellman-span
          |          actual density -> lem:mass-curvature
          |          global cells -> lem:injected -> actual resolvent
          |                              |
          +------------------------ thm:transfer
                                         |
         thm:gaussian / thm:quantum ------+ (hypothesis verification only)
                                         |
      thm:strata / internal halt / cap / precision / simulator / attained task
```

There is no arrow from a realization into the proof of the general theorem. R43's geometric-stop injection and the earlier acquired-curvature proof are inherited tools, explicitly attributed and reproved. `prop:effective` relies on exact transient ensemble representation plus additional computability inputs; not on experimental success of a fixed-point algorithm.
