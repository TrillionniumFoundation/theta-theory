#!/usr/bin/env python3
"""Finite algebra and implementation checks only; never a continuum proof."""
from __future__ import annotations
from fractions import Fraction as F
from collections import Counter
import json, math
import numpy as np
COUNTS=Counter()
def check(ok: bool, group: str, message: str)->None:
    if not bool(ok):raise RuntimeError(group+': '+message)
    COUNTS[group]+=1

def uniform_frontier()->None:
    for n in (F(1),F(3,2),F(2),F(5,2),F(3),F(10,3),F(4),F(5),F(15,2),F(10),F(16),F(20)):
            L=1/(2*n); w=L/2; g0=F(3,16)
            B=g0+1/(16*n)-1/(48*n*n)
            R2=g0+1/(8*n)-1/(16*n*n)
            R3=g0+1/(16*n)-1/(64*n*n)
            # Integrate g(1/4+x)=3/16+x/2-x^2 on both accepted tails.
            integral=4*n*(g0*w+w*w/4-w*w*w/3)
            check(integral==B,'uniform_integrals','full-history tail integral')
            check(R3-B==1/(192*n*n),'uniform_integrals','three-state gap')
            check(R2>=R3>=B,'uniform_integrals','ordered true frontiers')
            check(2*n*(g0*L+L*L/4-L**3/4)==R2,'uniform_integrals','one-code tail mean risk')
            for j in range(17):
                x=L*F(j,16);y=L-x
                tail_risk=g0+n*(x*x+y*y-x**3-y**3)/2
                check(tail_risk-R3==n*(2-3*L)*(x-L/2)**2/2,'uniform_tail_optimization','quadratic two-tail profile')
                check(tail_risk>=R3,'uniform_tail_optimization','balanced optimum')
            single_relax=g0+L/4-5*L*L/16
            check(single_relax-R3==L*(1-2*L)/8,'uniform_tail_optimization','single-tail two-center relaxation')
            for k in (2,3,4,7,12):
                left=k//2;right=k-left
                # Mean per-tail uniform quantization, weighted by half.
                err=w*w*F(1,24)*(1/F(left*left)+1/F(right*right))
                check(err>=F(1,48)/(n*n*k*k),'uniform_quantization','density lower constant')
                check(err<=F(1,8)/(n*n*k*k),'uniform_quantization','balanced code upper constant')


def killed_occupation()->None:
    # An iid positive instrument gives an exactly solvable finite analogue
    # of the occupation/Bellman identity. No density theorem is tested here.
    points=[F(1,4),F(1,3),F(2,5),F(1,2),F(3,5),F(2,3),F(3,4)]
    weights=[F(x,16) for x in (1,2,3,4,3,2,1)]
    g=lambda u:u*(1-u)
    for s in (F(1,2),F(1,4),F(1,16)):
      beta=1-s
      for cost in (F(1,1000),F(1,100),F(1,20),F(1,2)):
        candidates=[]
        for cutoff in sorted(set([F(0)]+[g(u) for u in points]+[F(1)])):
            stop=[g(u)<=cutoff for u in points]
            p=sum(w for w,b in zip(weights,stop) if b)
            a=sum(w*(g(u) if b else s*g(u)) for u,w,b in zip(points,weights,stop))
            C=(cost+a)/(1-beta*(1-p))
            if all((g(u)<=C)==b for u,b in zip(points,stop)):candidates.append(C)
        check(bool(candidates),'occupation_identity','Bellman threshold exists')
        C=candidates[0]
        W=lambda u:min(g(u),s*g(u)+beta*C)
        EW=sum(w*W(u) for u,w in zip(points,weights))
        check(C==cost+EW,'occupation_identity','full-history regularized value')
        for groups in (((0,1,2,3,4,5,6),),((0,1,2),(3,),(4,5,6)),tuple((j,) for j in range(7))):
            mass=[sum(weights[j] for j in G) for G in groups]
            q=[sum(weights[j]*points[j] for j in G)/p for G,p in zip(groups,mass)]
            h=[F(1) if g(u)<=C else s for u in q]
            T=1/sum(p*x for p,x in zip(mass,h))
            occupation=[T*p for p in mass]
            terminal=[p*x for p,x in zip(occupation,h)]
            risk=cost*T+sum(p*g(u) for p,u in zip(terminal,q))
            jensen=T*(sum(p*W(u) for p,u in zip(mass,q))-EW)
            check(sum(terminal)==1,'occupation_identity','absorption normalization')
            check(T<=1/s,'occupation_identity','actual duration safety')
            check(risk-C==jensen,'occupation_identity','single aggregate Jensen equality')
            check(jensen>=0,'occupation_identity','concave barycenter sign')
            check(sum(occupation)==T,'occupation_identity','actual call count')


def cantor_moments()->None:
    for r in (F(1,4),F(1,3),F(2,5)):
        m1=F(1,2);m2=1/(2*(1+r))
        check(m2==r*r*m2+r*(1-r)*m1+(1-r)**2/2,'cantor_moments','second-moment invariance')
        for h in range(1,10):
            n=2**(h-1);ell=r**h/2
            base=F(3,16)+ell/4-ell*ell/(2*(1+r))
            expected=F(3,16)+ell*m1/2-ell*ell*m2
            check(base==expected,'cantor_moments','conditional tail audit')
            check(F(2,2**h)==F(1,n),'cantor_moments','actual acceptance mass')
            cells=[(F(0),ell)]
            for j in range(0,6):
                check(all(b-a==ell*r**j for a,b in cells),'cantor_codes','computed cylinder diameters')
                check(all(cells[i][1]<cells[i+1][0] for i in range(len(cells)-1)),'cantor_codes','gaps preserve separate cylinders')
                conditional_variance=sum(F(1,len(cells))*(b-a)**2*(m2-m1*m1) for a,b in cells)
                check(conditional_variance==ell*ell*r**(2*j)*(1-r)/(4*(1+r)),'cantor_codes','conditional variance from all code cells')
                cells=[child for a,b in cells for child in ((a,a+r*(b-a)),(b-r*(b-a),b))]


def independent_stopping()->None:
    mu=[F(1,5),F(3,10),F(1,2)]
    for n in (F(1),F(3,2),F(2),F(7,2),F(10)):
        for code in ((F(1,2),F(1,3),F(2,3)),(F(1),F(0),F(1,2))):
            # Pick two accepted terminal classes at constant total acceptance 1/n.
            a1=[c/n for c in code];a2=[(1-c)/n for c in code]
            nu1=[p*a*n for p,a in zip(mu,a1)];nu2=[p*a*n for p,a in zip(mu,a2)]
            check(sum(nu1)+sum(nu2)==1,'terminal_disintegration','probability law')
            check(all(x+y<=n*p for x,y,p in zip(nu1,nu2,mu)),'terminal_disintegration','mean-budget domination')
            acceptance=sum(p*(x+y) for p,x,y in zip(mu,a1,a2))
            check(1/acceptance==n,'terminal_disintegration','paid geometric duration')
            check(all(p*a/acceptance==v for p,a,v in zip(mu,a1,nu1)),'terminal_disintegration','same-program terminal class')


def error_and_state()->None:
    for M in range(3,101):
        m=(M-1)//2
        check(1+2*m<=M and 4*m>=M,'state_accounting','initial/live/halt count')
        if M>=10:
            k=(M-4)//3
            check(4+3*k<=M and k>=2 and 6*k>=M,'state_accounting','bit product lanes')
    for a in [F(j,16) for j in range(17)]:
        eps=a/2
        check(a/4==eps/2,'attained_errors','erased fair 0/1 bit loss')
        for delta in (F(0),F(1,10),F(1,2)):
            for read in (F(-1),F(0),F(1,3)):
                check(((read-delta)**2+(read+delta)**2)/2==read*read+delta*delta,'attained_errors','invisible calibration signs')
    check(F(1,1)/(8*F(22,7)*3)>F(1,100),'gaussian_benchmark','rigorous pi/e rational envelope')


def positive_quantum_inverse()->None:
    rng=np.random.default_rng(45)
    def sqrt(a):
        val,vec=np.linalg.eigh(a)
        if np.min(val)<=0:raise RuntimeError('nonpositive numerical witness')
        return (vec*np.sqrt(val))@vec.conj().T
    def invsqrt(a):
        val,vec=np.linalg.eigh(a)
        return (vec/np.sqrt(val))@vec.conj().T
    for d in (2,3,4):
      for _ in range(8):
        z=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d));rho=z@z.conj().T+np.eye(d);rho/=np.trace(rho)
        h=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d));h=(h+h.conj().T)/2;h-=np.trace(h)*np.eye(d)/d;h/=np.linalg.norm(h)
        E=np.eye(d)+.4*h;A=sqrt(E);sigma=A@rho@A/np.trace(E@rho)
        B=invsqrt(rho)@sqrt(sqrt(rho)@sigma@sqrt(rho))@invsqrt(rho)
        recovered=d*(B@B)/np.trace(B@B)
        check(np.linalg.norm(recovered-E)<2e-11,'quantum_inverse_finite','congruence inverse on finite witnesses')
        check(abs(np.trace(E)-d)<2e-12,'quantum_inverse_finite','effect trace hyperplane')
        check(np.min(np.linalg.eigvalsh(.3*sigma+.7*np.eye(d)/d))>=.7/d-1e-12,'quantum_inverse_finite','prepared output buffer')


def informative_boundary()->None:
    for zeta in (F(1,4),F(1,2),F(4,5)):
        for u in [F(j,10) for j in range(11)]:
            weights=[(1+s*zeta*(2*u-1))/2 for s in (-1,1)]
            means=[u*(1+s*zeta)/(1+s*zeta*(2*u-1)) for s in (-1,1)]
            check(sum(weights)==1 and all(w>0 for w in weights),'boundary_kernel','positive normalized informative report')
            check(sum(w*v for w,v in zip(weights,means))==u,'boundary_kernel','Bayesian barycenter before transition')
            check(sum(w*(F(1,3)+v/3) for w,v in zip(weights,means))==(1+u)/3,'boundary_kernel','raw mean remains affine')
        b=F(9,10)
        check(b*(1+zeta)/(1-zeta)>1,'boundary_kernel','endpoint derivative expands')
        u=F(2,5);s=1;v=u*(1+s*zeta)/(1+s*zeta*(2*u-1));vp=(1-zeta*zeta)/(1+s*zeta*(2*u-1))**2
        ratios=[]
        for k in (20,100,1000):
            a=F(1,k);b=1-2*a;out=a+b*v
            ratio=u*(1-u)*b*vp/(out*(1-out));ratios.append(ratio)
            check(0<ratio<1,'boundary_kernel','positive report projective ratio')
        check(ratios[0]<ratios[1]<ratios[2],'boundary_kernel','contraction ratio approaches one')

def main()->None:
    uniform_frontier();killed_occupation();cantor_moments();independent_stopping();error_and_state();positive_quantum_inverse();informative_boundary()
    print(json.dumps({'status':'PASS','native_checks':sum(COUNTS.values()),'checks_by_group':dict(sorted(COUNTS.items())),'exact_rational_checks':sum(v for k,v in COUNTS.items() if k!='quantum_inverse_finite'),'floating_point_witness_checks':COUNTS['quantum_inverse_finite'],'limitations':'finite arithmetic and implementation witnesses only; not proofs over continuous kernels, all Borel programs, singular measures or infinite horizons; inherited counts are not added'},sort_keys=True,indent=2))
if __name__=='__main__':main()
