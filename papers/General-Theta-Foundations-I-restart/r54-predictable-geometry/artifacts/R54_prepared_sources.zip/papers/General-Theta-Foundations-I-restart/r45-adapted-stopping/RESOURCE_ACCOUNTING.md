# Resource accounting

| Resource | Costed general theorem | Exact independent-preparation class / joint extension |
|---|---|---|
| Raw acquisitions | tau>=1, each costs kappa; upper E tau<=2(1+L0/kappa), or one call for coarse budgets | E tau<=n, constructed rejection law uses exactly n in expectation; not a deterministic cap |
| Persistent states | at most 1+2m: one initial, m live, m halt; m=floor((M-1)/2) | one live plus k terminal labels, so k=M-1 exactly; joint prefix uses 4+3k<=M |
| Clock | no external phase input or deadline register | a stopping decision, not a free exact-n clock; geometric waiting does not require counting |
| Stored predictive coordinates | fixed offline table, not an extra runtime posterior register | fixed codepoints; no raw previous draw survives rejection |
| Sector / bit mark | conditional products and extra initial state counted in sector theorem | three bit lanes (0,1,erasure) included in 4+3k |
| Simulator state | target M times simulator R, plus any declared clock states | source/target maps must preserve bit-report deadline and audit |
| Program description | ideal Borel table distinct from finite bits; effective upper O(m(d+|A|+1)log(m+2)) plus primitive certificate | rational thresholds at rational n; finite cylinders at specified Cantor budgets; arbitrary real coefficients are not claimed computable |
| Temporary workspace | one current report approximation, vector and arithmetic; erased before next decision | threshold/cylinder evaluation and current report only |
| Numerical precision | direct per-cycle discrepancy eta, readout v; cost error <=T eta(L0+2 kappa/s)+v^2 | acceptance enlarged with certified error when required to preserve mean cap; same task tolerance charged |
| Offline synthesis | finite exhaustive enumeration and value intervals; potentially very expensive | explicit codes for displayed witnesses; no general efficient algorithm claim |
| Physical time | per-call evaluation cost times actual expected calls, plus fixed preparation and audit | total joint physical budget N=n+3 includes preparation, bit report, core calls and final audit |

The safety probability is an internal positive dyadic coin, not an external environmental reset or hazard. It costs O(log m) description bits, but no clock labels. For finite synthesis it remains bounded below by its selected s>0 in every candidate. Fixed-time earlier theorems have different M-n phase accounting and are not applied to this interface.

Calibration delta is a genuinely invisible coordinate in the matching joint example. Its exact worst-case squared contribution is delta^2. Erasure probability a gives attained complete-bit deficiency epsilon=a/2 and unavoidable squared bit loss a/4=epsilon/2 for the fair 0/1 convention. Numerical eta/v, model discrepancy, and causal deficiency are not interchangeable.
