# General Theta Foundations I — adapted stopping revision

The native manuscript is `main.tex`. Its title and mother problem are unchanged. This revision starts from the canonical restart and retains the complete R44 lineage on a new research branch; no old review, realization or archive ref is rewritten.

## Mathematical center

Theorem `thm:main` matches checkpoint and fully counted homogeneous finite-state excess risk under jointly optimized acquisition and unbounded proper stopping with a positive cost per call. Its proof uses actual first-run occupation, a small internal safety coin, Bellman curvature and cost absorption. There is no imposed hazard on the full-history comparator. The geometric assumptions are explicit: finite separating affine tests, actual row mass, a global cover, and either an interior buffer or the binary boundary certificate. The buffer can imply cone contraction and is not represented as innocuous.

The Gaussian and noncommuting quantum kernels verify the same theorem. A separate informative binary realization reaches the boundary, has locally expanding updates, and has no strict uniform same-report contraction. Immutable prepared sectors and an actual Cantor preparation give substantive nonuniform/singular results.

For independent paid preparations, `thm:frontier` characterizes the entire attained terminal-law set by `nu <= n mu`, and identifies the optimum autonomous curve with its checkpoint functional using exactly one live state and at most M-1 halting states. Uniform and Cantor examples give matching n--M laws. The uniform example also gives exact two- and three-state optima. Calibration and an attained causal deficiency are added in one protected task, with preparation and audit calls counted.

## Reading order

Read the native article first. `THEOREM_MAP.md` and `PROOF_LEDGER.md` map its complete proofs. `REFEREE_RESPONSE.md` and `REFEREE_COMMENT_CONCORDANCE.md` respond to the pinned R32 report. Companion M preserves the full recovered R44 article; Companion L preserves R43; all earlier full companions retain separate identities. They are not an enlarged editorial submission or hidden premises for new results.

## Status discipline

A source commit, artifact commit and final evidence commit are distinct. Current authoritative status is in `evidence/REFEREE_PACKET.md` when that file has actually been published. Intake, source export, finite regression, PDF builds and independent reconstruction do not establish continuum correctness, priority, significance or journal acceptance. No such certification is claimed.
