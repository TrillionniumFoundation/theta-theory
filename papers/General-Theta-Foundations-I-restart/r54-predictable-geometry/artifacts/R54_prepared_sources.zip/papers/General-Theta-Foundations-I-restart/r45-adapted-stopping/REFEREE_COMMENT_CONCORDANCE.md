# Referee comment concordance

Pinned complete R32 external report, blob `3731f79996e11cdac66ce7c8a3ee5fdf1fffcd21`. Native and retained answers are distinguished; a historical statement is not newly certified merely by appearing in a companion.

## Twelve major requests

| Comment | Concern | Response / location |
|---|---|---|
| 17.1 | Finite affine class in first abstract sentence | main.tex; sec:experiment; quotient image/section and interface flags explicit. |
| 17.2 | Identity versus geometric hypotheses | thm:main and lem:calibration separated from row mass and value-regularity assumptions. |
| 17.3 | Uniform geometry on all retained barycenters | def:regular is for every a,u in D; raw Gaussian, quantum and boundary proofs verify it. |
| 17.4 | Local versus global recursive compatibility | Actual first-run fixed point and resolvent lem:calibration; full previous general routing criterion retained as Companion M. |
| 17.5 | Value-directed belief-compression comparison | sec:comparison and LITERATURE_COMPARISON.md; no novelty claim for value-directed compression itself. |
| 17.6 | Bayes-risk/Bregman quantization comparison | Varshney2011 cited; projection/Bregman interpretation marked standard. |
| 17.7 | Current finite-memory POMDP comparison | Kim2026 v1 and partition-observation 2026 paper checked; fixed-policy versus optimized benchmark distinguished. |
| 17.8 | Separation of old sufficient mechanisms | Old (C)/(P) proofs/counterexamples remain in full companions; new main removes need for these routes and adds explicit no-overlap and no-buffer witnesses. |
| 17.9 | Autonomous clock interpretation | All initial/live/halt labels counted; old M-n exact-deadline law not promoted to free stopping. |
| 17.10 | Recognizable Gaussian benchmark | prop:gaussian-stop gives explicit parameters and strict stopping/continuation regions. Exact finite Gaussian optimal table is NOT claimed; additional independent primitive has exact M=2,3 optimum. |
| 17.11 | Quantum physical positioning | Raw positive weak effects, channel, noncommutation and performed randomized audit stated. No claim to solve general reference-frame filtering. |
| 17.12 | Companion hierarchy | New native proofs self-contained; complete R44 as M and predecessors as separately identified technical companions. |

## Thirty-two technical comments

| Comment | Concern | Response / location |
|---|---|---|
| 18.1 | Old perspective Hessian notation | Retained R32/H formula remains its own result; new raw formula uses U,ell,F and no ambiguous F(cv). |
| 18.2 | Likelihood row scalar functional | Raw L decomposition in sec:experiment is affine; scalar ell is kept separate from vector U. |
| 18.3 | Attained quotient versus certificate domain | lem:quotient explicitly separates attained Borel image from compact B,D,K; no ambient image identifies actual mass. |
| 18.4 | Uniform common-null versions | Raw identities are fixed off common report null sets on the whole declared domain. |
| 18.5 | Zero likelihood numerator | sec:experiment states positivity and bounded tests force U=0 there; main quantitative assumptions use positive likelihood. |
| 18.6 | Support equivalence for all programs | Current free-stopping theorem does not invoke a phase-clock lower. All-row positivity is quantified over D, including true histories and mixtures; old clock theorem retained. |
| 18.7 | Positive-support paths in clock proof | No reused old fixed-n clock inference in native text; full historical proof preserved in companions. |
| 18.8 | Repeated readouts reduce codepoints | q_M and lem:converse use at most M values; exact independent frontier uses at most M-1 halting values. |
| 18.9 | Constants near loss of stability | No old rho-dependent uniformity carried over. Main constants depend on kappa and declared geometry; zero-price and buffer boundaries explicit. |
| 18.10 | No extra real-valued output register | Label-only stored readouts; finite-bit table and temporary workspace separate. |
| 18.11 | Report-first Gaussian convention | Raw Gaussian section explicitly reports before applying P; benchmark uses the same order. |
| 18.12 | Affine likelihood-rank determinant | Gaussian proof explicitly includes its determinant lower among constants. |
| 18.13 | Hilbert contraction alpha/dimension | Not an input to new proof; old bound kept with old hypotheses. P_ij>=a0 and column normalization remain explicit. |
| 18.14 | Quantum audit basis norm | HS-orthonormal T_J, hence operator norm<=1; randomized binary effect stated. |
| 18.15 | Trace-h effect domain | Traceless H implies tr(I+eta H)=h; inverse explicitly normalizes to that hyperplane. |
| 18.16 | Cone contraction parameter dependence | New proof does not use old H0/rho; lambda,eta and physical dimension enter geometry constants, with degeneracy excluded. |
| 18.17 | Prepared domain before improving step | New u0 in D is required from the start. Old bounded-gap theorem remains complete in H and later retained texts. |
| 18.18 | Current rank mark versus old mark | Native sector theorem intentionally has an immutable prepared mark, stated as a DIFFERENT class. Old changing-rank statement remains unchanged, not relabeled. |
| 18.19 | Centers outside an orbit | Native small-ball lower permits arbitrary ambient centers; old projective-orbit proof retained rather than reasserted without its enlargement step. |
| 18.20 | Component allocation not optimal | Fixed-weight sector upper gives a sufficient allocation and its actual count, not an optimal weight allocation theorem. |
| 18.21 | Observer coins in simulator law | prop:morphism includes target observer coins and full stopped/scored coupling. |
| 18.22 | Unconditional row bound, not no-mismatch conditioning | lem:routing derives uniform actual-history domination; prop:precision sums first-discrepancy probabilities correctly per cycle. |
| 18.23 | Gaussian numerical tail is charged | Effective certificate treats outside-box report as a discrepancy, never a new unreported physical event or free conditioning. |
| 18.24 | Conditional independence of retained bit | cor:joint proves core independence even under all allowed actions/reports/stopping; no later bit disclosure. |
| 18.25 | Bit convention and squared loss | New native bit is fair 0/1 with response in [0,1], erased loss 1/4. Old +/-1 results remain separate. |
| 18.26 | Conversion from actual deficiency | Native epsilon=a/2 and bit squared term a/4=epsilon/2 stated exactly; old checkpoint formula not transplanted. |
| 18.27 | Small budgets and product algebra | M>=10, k=floor((M-4)/3)>=M/6, 4+3k<=M; main M>=3 has 1+2m and m>=M/4. |
| 18.28 | Dimension-dependent audit normalization | L0 is explicit; quantum randomized audit second moment is d^2/b^2, not dimension-free. |
| 18.29 | Scope of all-program language | Native quantifiers say all legal history-dependent sensing/stopping or all Borel finite-state observers of the declared class; no unknown-control-class upgrade. |
| 18.30 | References years and identifiers | All added preprints have year/arXiv; journal articles have year/DOI. Current versions pinned in literature comparison. |
| 18.31 | Build counts outside introduction | Counts appear only in receipts/audit material, not formal mathematical introduction. |
| 18.32 | Original R27 / corrected F / R29 / R32 | SOURCE_LINEAGE, HISTORY_COVERAGE and inherited build chain keep these distinct; no historical text overwritten. |

The report’s broader significance requests are answered by new optimized-stopping and exact acquired-law theorems, not by claiming an editorial reversal. General necessity, unknown-kernel learning and the full computational lower frontier are explicitly not closed.
