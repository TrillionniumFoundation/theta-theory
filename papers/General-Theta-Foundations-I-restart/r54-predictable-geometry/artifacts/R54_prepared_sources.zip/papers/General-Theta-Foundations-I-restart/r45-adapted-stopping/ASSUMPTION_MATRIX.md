# Assumption matrix

| Hypothesis | Main buffered case | Binary boundary case | Exact prepared frontier | Purpose |
|---|---|---|---|---|
| Known normalized raw positive instrument | yes | yes | explicit iid preparation kernel | actual causal law, no parameter oracle |
| Standard Borel, finite separating affine test closure | yes | yes | scalar/vector response test, direct iid kernel | normalized predictive update derived from raw numerator |
| Borel attained image and Borel history section | declared; verified by compact exhaustions in two realizations | verified in boundary realization | direct report realization | standard Borel quotient/minimality, not supplied to runtime |
| Legal-interface flag | initial/continuing/halting separately | same | one live versus halting | prevents comparing different legal futures |
| Finite always-legal sensor library | yes | yes | a fixed paid preparation | adaptive control quantifier |
| Actual acquired row upper density for every incoming retained mixture | yes | yes, Lambda=2 in realization | replaced by arbitrary actual mu | all-stopping small-ball and curvature |
| Global legal grid, null boundaries | yes | interval grid | measurable code/acceptance kernel | actual implementability |
| Interior output buffer | yes; can imply cone contraction | NO; K=D=B=[0,1] | not required | one route to value Lipschitz |
| Alternative global value Lipschitz from raw task | not needed | 0<=W<=u(1-u) and concavity imply Lip<=1 | not used | avoids hidden uniform contraction requirement |
| Feedback-uniform common overlap | NOT required | NOT required | NOT required | explicit disjoint-action witness shows distinction |
| Proper stopping, no external hazard | optimized; kappa>0 | optimized; kappa>0 | optimized; E tau<=n | actual stopping class |
| Positive cost kappa | fixed and positive | fixed and positive | not a premise | bounds near-optimal occupation; no zero-price uniformity |
| Full-history risk subtracted | V_kappa of SAME stopped task | same | B_n for SAME core task | avoids incomparable Bayes baselines |
| Unknown calibration alternatives | only separate same-task extension | same | explicit invisible +/-delta | attained lower, not an allowance interpreted as necessity |
| Causal deficiency | complete-law typed simulator + duration | same | explicit erased-bit prefix | errors and simulator states priced separately |
| Effective primitive/report/routing certificates | extra assumption for finite-bit synthesis | direct H,L_F and integration in realization | exact Borel frontier; numerical implementation additionally certified | no computation inferred from measurability |

The autonomous budget counts initial, live, halt and any stored sector/bit lane. A current report is temporary; its precision, evaluation time and workspace are separately charged. M does not mean total bit complexity. The prepared sector theorem fixes actual mark weights; it does not condition away rare mass or allow abandoning an unwanted sector.
