# Notation and interface audit

| Symbol | Meaning | Never substituted by |
|---|---|---|
| B, D, K | ambient affine base, certificate domain, actual one-call support carrier | a preassigned parameter manifold |
| X_t | full-history conditional future-test vector | retained finite state or uncharged machine memory |
| S / S_t | retained label in general notation; binary report S in the explicit boundary example is local | a public infinite random seed |
| L_a, ell_a, U_a, F_a | raw positive instrument, likelihood, numerator, normalized update | independent covariance/Fisher input |
| mu_{a,u} | actual one-call law from incoming predictive u | reachable-set counting measure |
| mu in lem:calibration | unnormalized pooled-row visit law, mass T | full-history terminal probability nu |
| nu | actual terminal predictive law | one-call law conditioned without its acceptance cost |
| T | E tau, actual number of core calls | terminal label count or deterministic horizon |
| kappa | fixed positive cost per core call | an imposed stopping hazard |
| s, beta=1-s | internal candidate safety coin and survival | environmental erasure/refresh or a free clock |
| W_kappa, W_s | post-report stopping values | a fixed-policy value advertised as unrestricted control |
| V_kappa | same-task full-history benchmark after mandatory call | the benchmark from a different policy or horizon |
| M,m,k | total labels; internal grid count; terminal code count | total bits, workspace, or output precision |
| n,N | expected core acquisition cap; total physical expected cap in joint example | pathwise maximum |
| delta | invisible calibration magnitude in the attained example | arbitrary tolerance interpreted as a lower bound |
| epsilon | actual causal deficiency for matching prefix, or declared complete-law bound in transfer | numerical report-bin error |
| eta,v | compiled per-cycle discrepancy and readout norm error | delta/epsilon without a common task justification |
| h | physical Hilbert dimension in quantum section; grid scale in local proof | a new hidden phase variable |

Scalar binary audit uses fair 0/1 bits and loss 1/4 on erasure, not the earlier +/-1 convention. Higher-dimensional audit loss bound L0 remains explicit. All generated theorem labels and references are checked by `verify.py` and actual `.fls` input records; these checks are lexical, not mathematical certification.
