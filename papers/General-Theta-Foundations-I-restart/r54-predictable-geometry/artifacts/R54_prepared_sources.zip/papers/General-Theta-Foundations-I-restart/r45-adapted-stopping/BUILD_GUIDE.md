# Immutable-source build guide

Requirements: Python 3 with numpy and pypdf, pdflatex with amsmath/amsart, geometry, lmodern, microtype and hyperref, and Poppler pdfinfo/pdftotext. The retained chain also uses its declared standard LaTeX packages. No shell escape, OCR or external mathematical computation is needed for PDF generation. The finite checks are not proofs.

From the repository root:

```bash
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python papers/General-Theta-Foundations-I-restart/r45-adapted-stopping/verify.py
python papers/General-Theta-Foundations-I-restart/r45-adapted-stopping/regression.py
python -O papers/General-Theta-Foundations-I-restart/r45-adapted-stopping/regression.py
python papers/General-Theta-Foundations-I-restart/r45-adapted-stopping/build.py   --source-sha <actual-ordinary-source-commit>   --expected-tree <actual-R45-ordinary-source-projection>   --output /tmp/r45-build --receipt /tmp/r45-build-receipt.json
```

`verify.py` checks the entire ordinary text manifest, source tree projection, active TeX inputs, balanced environments, references, bibliography and pinned review blob. `native_build.py` runs normal and optimized finite checks, builds twice from two clean isolated source copies, and performs three LaTeX passes each. Actual `.fls` TeX inputs must match the inventory. Undefined references, multiply defined labels and overfull boxes fail the build. Source bytes are not modified.

`build.py` also builds the complete unchanged R44/R43 and earlier mathematical chain, verifies their exact projections, and exports every full companion, not excerpts. The resulting receipt records nested counts without summing them as independent tests. A source SHA argument binds the input, but final publication must separately verify that the SHA actually exists remotely. Independent reconstruction uses the downloaded remote packet, not the original authoring directory.

Within-environment byte reproducibility, cross-environment normalized text/page comparison and visual rendering are different checks and must be reported separately. A missing cross-environment byte match is not to be concealed. Final evidence-only commits are excluded from the ordinary mathematical projection, so no self-referential SHA promise is required.
