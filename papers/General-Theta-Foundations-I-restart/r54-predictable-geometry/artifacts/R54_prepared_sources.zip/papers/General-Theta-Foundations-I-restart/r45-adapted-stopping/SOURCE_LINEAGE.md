# Source lineage

The R45 research ref was created at the canonical restart `18000b21e4bfd89180ccb069e46ac0f21621f34d`. Commit `6a152ec8abecb6353338b87b9b429ceee765e487` has that first parent and R44 `fd97bedc63e130a39006bd46d35f3f309edb0093` as its second parent, retaining the latter tree plus a new intake and read-only export workflow. The filtered-export commit is `170261f2b8f774536257eb060eff7b490bf400b3`.

The first export included historical binary products and exceeded the connector download size; it was NOT downloaded. The subsequent source-only export succeeded as run `38248137200`, artifact `11746499313`, and was actually downloaded. Its `PINNED_EXPORT.json` records Git blob identities. R43 ordinary-source artifact `11742906532` from run `38232315892` was also actually downloaded. R44 ordinary text is recovered from its pinned nine-part LZMA transport; its hash and source projection are independently checked.

R43 ordinary projection: `bdbbac591826cff47200a6e0601dcdd48e5400c9`.
R44 ordinary projection: `701db04f35ed3956ab4a51415fe9d03796912573`.
R44 compressed transport SHA-256: `b2a53a6f5f2fd8344c7e201369e3a20151dc311adb5032e8be97eb79e923d161`.

R45 is a new manuscript source, not a renamed copy of v96 or of a realization. The old full R44 mathematical article is an independent Companion M. Reconstruction and delivery are not new mathematics. Later `evidence/SOURCE_PUBLICATION.json`, `BUILD_RECEIPT.json`, independent receipt and `REFEREE_PACKET.md` bind ordinary-source, artifact and final evidence commits; this document deliberately does not guess those future SHAs.
