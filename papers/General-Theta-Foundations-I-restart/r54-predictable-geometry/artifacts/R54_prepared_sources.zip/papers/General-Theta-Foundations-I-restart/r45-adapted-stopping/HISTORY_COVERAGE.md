# Historical coverage and preservation

## Remote baseline actually checked

Canonical restart: `18000b21e4bfd89180ccb069e46ac0f21621f34d`.
Latest external report found at intake: R32 review commit `65bd07d89b04274c587d2ae4100511d99c39b0f2`, report blob `3731f79996e11cdac66ce7c8a3ee5fdf1fffcd21`.
R43 successful ordinary-source branch: `1909092aeccc74b227fb568eafad6e958efb62d5`, successful run `38232315892`.
R44 research head: `fd97bedc63e130a39006bd46d35f3f309edb0093`; its publication run `38244579074` failed and produced no export artifact. R45 preserves and reconstructs this source on a NEW branch; it does not declare the old failed run successful.

## Direct reading and audit

The four controlling files were read, including the original v0.1 mother-program statement. The complete R32 report, its major and technical comments, and the R43/R44 mathematical sources, proof ledgers and build dependencies were inspected for the stopped-disintegration problem. The new article's raw definitions, Bellman proof, occupation fixed point, lower, two primitive verifications, binary boundary proof, exact frontier, singular and error proofs were directly audited. Selected preceding pipeline derivations were read to locate the inherited mechanisms. `provenance/PIPELINE_INVENTORY.json` inventories every pipeline derivation present in the exported restart tree; inventory does not mean every historical proof has been re-proved.

## Full retained mathematical build chain

Companion M is the complete recovered R44 article. Companion L is R43; K is R38; J is R37; I is R34; H is reviewed R32. G/F/E/D/C/B/A/X/W/V/U/T/S retain the preceding full chain as identified by the inherited build receipts. Original R27 and its explicitly corrected Companion F remain distinct. None is silently rewritten, downgraded or used as a premise in place of the new native proof.

All prior restart subtrees and four control-file objects are checked for byte identity against the pinned export, except that missing ordinary R43/R44 source is reconstructed from its original hashed transport on this new branch. Old refs are read-only throughout. Frozen v1--v96 and independent realization branches are preserved by not writing them. Their topology is not claimed to have been exhaustively re-certified.

## Explicit limits

This round does not claim a new line-by-line proof audit of all v1--v96, every historical report, every original v1 source, or every independent realization paper. Preserving and rebuilding a full mathematical companion is not equivalent to independently re-proving all its theorems. The build chain is the actual native dependency packet, not every paper in the repository. Remote final readback records the refs actually rechecked, without treating a limited search as an editorial acceptance certificate.
