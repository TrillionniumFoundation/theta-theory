# Proof audit and remaining obligations

## Quantifiers checked

The core infimum is over every legal Borel full-history sensing/stopping rule with mandatory first acquisition and finite mean duration. Autonomous competitors have a homogeneous finite label set with fixed live/halt status and label-only readout. All past private randomness not in those labels is unavailable. Known model data may enter the offline table; true unknown parameters are not supplied. The exact independent-preparation theorem covers arbitrary compact preparation measures, not arbitrary correlated kernels.

## Most sensitive steps

* Bellman properness is proved from positive running cost before infinite-horizon verification. The safety problem is a candidate restriction, never a restriction of the comparator.
* The fixed point is over finite unnormalized physical/predictive ensembles. Its graph uses common-null positivity, weak row continuity, null cell boundaries and integrable raw operator norms. Zero rows contribute zero, so their arbitrary representatives cause no division defect.
* Once the table is frozen, its continuing positive map has mass at most 1-s on every positive ensemble. The unique resolvent is the actual first run, not a stationary substitute.
* The pooled pre-routing occupation law and the full-history terminal law are DIFFERENT measures. They enter the upper and lower respectively. Their domination constants include actual mean duration.
* Curvature is integrated against true mass. A convex Lipschitz infimal extension supplies the boundary estimate. Binary endpoint concavity gives the alternative global Lipschitz certificate without a buffer.
* Total-state accounting is 1+2m, not m. The finite-bit construction does not retain any exact history state outside these labels.
* Calibration holds under occupation, not at each deterministic time. The rounding proof therefore derives actual-history report domination separately. In the boundary realization it is verified directly.
* The constrained frontier is proved by exact measure domination and acceptance disintegration, not by interchanging an infimum with a Lagrange supremum. The two-state and three-state lower is an optimization over all accepted measures and all terminal readouts, not a finite code search.
* Coupling controls unbounded acquisition cost only with a duration estimate. Finite precision is priced per acquisition AND its following decision, not twice counted by an unexplained clock.

## Claims not made

No necessity classification for the general mass/cover hypotheses is proved. The buffer is strong and can imply cone contraction; its removal is proved only through the specified binary boundary alternative, not in all dimensions. Mean-budget duality for general correlated sensing, arbitrary selected strata, arbitrary nondominated/infinite-dimensional carriers and unknown-kernel learning rates are not established. The general Gaussian theorem gives a fully specified abstract construction and a genuine binary stopping benchmark, not a closed-form optimal M-state Gaussian controller with all numerical sharp constants.

The effective theorem proves finite termination and a description upper under effective primitive certificates. It does not prove a polynomial algorithm, a complexity lower, optimal workspace, physical time, or minimal simulator state. Noncomputable Borel data remain an ideal mathematical resource model. Priority and general-journal importance require independent assessment. Finite regressions and builds are not proof certificates.
