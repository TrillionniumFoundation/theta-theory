# Theorem dependency map

```text
prepared raw instruments + separating affine future tests + legal interface
  -> quotient / affine conditional integration (lem:quotient)
  -> actual row law and task g
  -> Bellman properness / safety value (lem:bellman)
       -> uniform Lipschitz bound by buffer OR binary endpoints
  -> common-cell positive cone correspondence
       -> actual killed first-run calibration (lem:calibration)
       -> one Bellman--Jensen occupation defect
  -> mass--curvature (lem:curvature) + positive cost absorption
       -> fully counted finite observer upper
actual pre-call row mass + all adapted stopping
  -> stopped-mass domination (lem:converse)
  -> quantization lower + near-optimal cost bound
  -> THEOREM thm:main (matching cp/aut rates)

raw Gaussian -> thm:gaussian -----------|
raw quantum -> thm:quantum ------------| verify, do not prove, thm:main
raw informative binary -> thm:boundary-|
immutable raw sector mixture -> thm:sectors

independent paid raw preparation
  -> attained law nu <= n mu (thm:frontier)
  -> exact finite-state/checkpoint functional
       -> uniform exact optima and matching n--M (prop:uniform)
       -> singular Cantor matching (cor:cantor)
       -> attained same-task errors (cor:joint)

typed simulator + complete law + duration coupling -> prop:morphism
raw routing domination + rounding -> prop:precision / lem:routing
positive safety + effective physical integration -> cor:effective
```

The frontier theorem is a separate exact class theorem. Its independence hypothesis is not imported into the mother theorem or its Gaussian/quantum realizations. The costed theorem is not used as an unjustified duality argument for mean-budget equality. Retained Companion M supplies provenance for reproduced curvature/calibration mechanisms, not missing proofs.
