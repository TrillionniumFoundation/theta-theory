# Counterexample and boundary ledger

| Tempting but invalid inference | Concrete witness or boundary | Native location |
|---|---|---|
| Every stopped law inherits a one-call density bound | Two narrow accepted endpoint tails have density 1/(2h), while every iid call is uniform density 2; E tau=1/(4h) | prop:zero-cost, lem:converse |
| Fixed M forces a positive gap with zero price and unbounded mean | Three labels approach full-history infimum 3/16 as h tends to zero | prop:zero-cost |
| Actual one-step continuous mass must survive optimized stopping | Accept only an available atom, with finite mean reciprocal atom mass | ex:atom |
| Main proof needs common feedback overlap | Two actions have disjoint acquired supports but satisfy buffered mass hypotheses | ex:no-overlap |
| No contraction estimate in a proof means buffer has no contraction implications | Buffer maps a cone base uniformly into its interior; audit explicitly acknowledges this | def:regular, sec:comparison |
| Every covered realization is uniformly report-contracting | Informative binary updates reach both endpoints, expand some Euclidean differences, and have reportwise projective contraction supremum one | thm:boundary |
| Arbitrary balanced occupation is the actual initial-run law | At s=0 harmonic/invariant mass can persist independently of preparation; proof keeps s>0 and z=sum P^t b | lem:calibration; Companion M retains general realization criterion |
| Occupation representatives equal fixed-time representatives | They need not; numerical routing uses uniform likelihood domination for every true history | lem:routing |
| A formal reachable carrier supplies probability mass | Main small-ball bounds use actual rows and true E tau; exact frontier uses nu<=n mu | lem:converse, thm:frontier |
| A prescribed exact-n clock lower survives free stopping | An iid accept/reject experiment has one live state at arbitrary finite mean | thm:frontier |
| Same terminal TV controls unbounded acquisition cost | Identical terminal outputs with arbitrarily long extra waiting | ex:duration |
| Finite-dimensional physical coordinates imply a Borel quotient automatically | Arbitrary Borel maps can have only analytic images; section/image hypothesis is explicit and verified in smooth raw classes | lem:quotient |
| Numerical finite reports must be TV-close to continuous reports | Quantizing a continuous report can be singular; compare routing/primitive failure under actual report mass instead | prop:precision |
| A delta/epsilon upper allowance is an unavoidable loss | Delta is invisible +/-delta and epsilon is attained by an explicitly erased bit in cor:joint; generic transfer is only an inequality | cor:joint, prop:morphism |

The examples delimit proofs; they are not a replacement of the mother problem by an impossibility paper. Historical counterexamples retain their original interfaces in unchanged companions.
