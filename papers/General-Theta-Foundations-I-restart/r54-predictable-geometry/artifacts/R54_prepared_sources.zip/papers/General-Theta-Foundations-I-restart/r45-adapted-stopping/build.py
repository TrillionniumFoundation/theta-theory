#!/usr/bin/env python3
"""Native R45 plus full unchanged recovered R44 and deposited earlier mathematical articles."""
from __future__ import annotations
import argparse,json,sys,tempfile
from pathlib import Path
import native_build
from native_build import run
from verify import ROOT,require,verify,sha256
R44_TREE='701db04f35ed3956ab4a51415fe9d03796912573'
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source-sha');ap.add_argument('--expected-tree');ap.add_argument('--output',default=str(ROOT/'artifacts'));ap.add_argument('--receipt',default=str(ROOT/'evidence/BUILD_RECEIPT.json'));args=ap.parse_args()
    before=verify();out=Path(args.output).resolve();out.mkdir(parents=True,exist_ok=True)
    if args.source_sha:require(before['review_input_verified'],'published build requires pinned external report')
    with tempfile.TemporaryDirectory(prefix='theta-r45-full-') as td:
        td=Path(td);native=td/'native.json';old=td/'retained.json';argv=sys.argv[:]
        sys.argv=['native_build.py','--output',str(out),'--receipt',str(native)]
        if args.source_sha:sys.argv+=['--source-sha',args.source_sha]
        if args.expected_tree:sys.argv+=['--expected-tree',args.expected_tree]
        try:native_build.main()
        finally:sys.argv=argv
        current=json.loads(native.read_text());oldout=out/'retained';oldout.mkdir(exist_ok=True)
        cmd=[sys.executable,str(ROOT.parent/'r44-stopping-disintegration/build.py'),'--expected-tree',R44_TREE,'--output',str(oldout),'--receipt',str(old)]
        if args.source_sha:cmd+=['--source-sha',args.source_sha]
        run(cmd)
        previous=json.loads(old.read_text());require(previous['ordinary_source_projection_tree_sha']==R44_TREE,'R44 recovered ordinary source changed')
        (out/'General_Theta_Foundations_I_R45_Companion_M.pdf').write_bytes((oldout/'General_Theta_Foundations_I_restart_R44.pdf').read_bytes())
        for letter in ('L','K','J','I','H','G','F','E','D','C','B','A','X','W','V','U','T','S'):
            (out/f'General_Theta_Foundations_I_R45_Companion_{letter}.pdf').write_bytes((oldout/f'General_Theta_Foundations_I_R44_Companion_{letter}.pdf').read_bytes())
        current.update(component='General Theta Foundations I restart R45 adapted stopping',retained_complete_R44=previous,total_isolated_pdf_builds=previous['total_isolated_pdf_builds']+2,technical_pdf_builds=previous['technical_pdf_builds']+2,cover_pdf_builds=previous['cover_pdf_builds'],deposited_R44_unchanged=True)
        from pypdf import PdfReader
        current['delivery_pdfs']={p.name:{'sha256':sha256(p.read_bytes()),'pages':len(PdfReader(p).pages),'bytes':p.stat().st_size,'normalized_text_sha256':sha256(' '.join(run(['pdftotext','-enc','UTF-8',str(p),'-']).split()).encode())} for p in sorted(out.glob('*.pdf'))}
        current['total_delivery_pages']=sum(x['pages'] for x in current['delivery_pdfs'].values())
        current['limitations']='Native R45 plus full recovered R44 as M, R43 as L, R38 as K, R37 as J, R34 as I, R32 as H and earlier complete companions. Recovery of R44 is on this new branch, not certification of its failed old build. Original R27/corrected F remain distinct. Not every historical paper. Finite tests/builds do not certify continuum proofs, priority, significance or acceptance.'
        require(verify()==before,'ordinary source changed during full build')
        rp=Path(args.receipt);rp.parent.mkdir(parents=True,exist_ok=True);rp.write_text(json.dumps(current,sort_keys=True,indent=2)+'\n');print(json.dumps(current,sort_keys=True,indent=2))
if __name__=='__main__':main()
