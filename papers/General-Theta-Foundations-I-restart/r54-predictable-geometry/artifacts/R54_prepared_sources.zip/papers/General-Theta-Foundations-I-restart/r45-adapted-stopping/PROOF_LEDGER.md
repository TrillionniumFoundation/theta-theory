# Proof ledger

All identifiers below are native TeX labels; final theorem numbers are recorded from the compiled auxiliary file in the build receipt. “Proved” means the manuscript contains the indicated argument, not that a formal proof assistant or independent referee has certified it.

| Result | Core argument | Status and prerequisites |
|---|---|---|
| `lem:quotient` | Eventwise affine conditional integration; Borel factor through a declared section | Proved with explicit Borel-image/section hypothesis and legal-interface flag; no general analytic-image assertion |
| `lem:bellman` | Monotone finite-horizon limit, concave perspective, positive-cost properness, internal safety coupling | Proved for all legal history-dependent sensing/stopping; buffer or binary boundary yields uniform Lipschitz bound |
| `lem:curvature` | Convex Lipschitz infimal extension, distributional Laplacian, cell mass and bounded overlap | Inherited mechanism, re-proved without excluding boundary points |
| `lem:calibration` | Kakutani correspondence over finite cone ensembles; frozen positive resolvent equals the actual first run | Proved for candidate safety s>0; never identifies arbitrary invariant mass as preparation-induced occupation |
| `thm:main` upper | One aggregate Bellman--Jensen defect; kappa T absorbs G T m^(-2/d); 1+2m labels | Proved for fixed positive kappa; no uniformity at zero price |
| `lem:converse` | Pre-call measurability, Tonelli, stopped mass <= Lambda E(tau) volume, small balls | Proved for every legal adaptive stopping policy; not a terminal law conditioned from a one-step density |
| `thm:main` lower | Projection plus nonnegative full-history suboptimality; cost bounds near-optimal duration | Proved for both architectures, with actual stopping law |
| `thm:gaussian`, `prop:gaussian-stop` | Raw report-first transition, full log-odds density, buffer, Borel sections; strict stop/continue regions | Proved from kernels; no Gaussian tail discarded; benchmark is genuinely nontrivial |
| `thm:quantum` | Positive instrument, effect-congruence inverse/Jacobian, physical randomized audit | Proved in finite dimension, no shared eigenbasis or observer quantum memory |
| `thm:boundary` | Informative binary likelihood, random affine transition, uniform actual density 2; endpoint concavity | Proved without output buffer; local derivative can exceed 1 and strict uniform report contraction fails |
| `thm:sectors` | Conditional main theorem with actual fixed sector weights; complete label allocation | Proved for immutable prepared marks; not arbitrary dynamic selection of strata |
| `thm:frontier` | Necessity from iid pre-call occupation, sufficiency by a shared acceptance kernel, compact minimization | Exact for independent paid preparations, arbitrary compact singular preparation law |
| `prop:uniform` | Lowest-risk level-set allocation, exact moment integration, finite-output quantization | Proved for all legal programs, including exact M=2,3 optima |
| `cor:cantor` | Cylinder mass and scales, second moment, dominated-law small balls | Proved at stated dyadic mean budgets and k>=2; no ambient-dimension substitution |
| `cor:joint` | Independent core lower, invisible-sign average, attained erased-bit deficiency, counted product machine | Proved for displayed N,M and bounded delta,epsilon; mean budget and true epsilon specified |
| `prop:morphism` | Coupling complete stopped/audited law plus explicit duration discrepancy | Proved; unbounded time needs its own expectation bound |
| `prop:precision`, `lem:routing` | First discrepancy per acquisition/decision cycle; actual-law domination and grid slabs | Proved; not timewise calibration inferred from occupation calibration |
| `cor:effective` | Round an existing calibrated program; enumerate finite effective candidates with safety; certify physical value intervals | Conditional effective theorem proved; no computable fixed-point selection assumed and no efficient synthesis claim |
| `prop:zero-cost` and boundary examples | Explicit rare acceptance, separated actions, atom selection and clock counterexamples | Proved sharpness/interface checks |

No new theorem invokes a realization as a premise. No numerical test is a dependency of a continuous proof. Bare Borel coefficients do not imply effective finite-bit synthesis. Full classification, general unknown-model learning and a matched computational lower frontier remain open obligations of the broader research program, not completed claims here.
