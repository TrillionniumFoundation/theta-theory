Compile main.tex with pdflatex three times. All TeX inputs are local. No font files are included.
