# Hostile proof audit - v9

## Repaired blockers

1. **No preferred lattice coordinate.**  The primitive current is the full homology cocycle `kappa_R in Z^2`; scalar currents are contractions by covectors.
2. **Current and clock are not separated.**  The physical pressure root is defined by `P_R(xi,H_R(xi))=0`; velocity and diffusion are its gradient and Hessian, with `G=kappa-v tau`.
3. **Microcanonical conditioning is not declared Markov.**  A two-sided central theorem conditions exact vector displacement and a shrinking macroscopic roof window.  Its quantitative estimate allows logarithmically growing value-relevant blocks.
4. **Roof conditioning does not assume a uniform temporal lattice LLT.**  Fourier inversion is used only for lattice displacement; the roof is handled by a joint spectral Laplace principle on a shrinking interval.
5. **Global pressure is not silently identified with microscopic dynamics.**  Smooth microscopic formulas are local to the common simple spectral component.  The global lower-semicontinuous object is a variational PDE continuation unless a separate global empirical-process LDP is proved.
6. **The scalar theta coefficient is not free in the first-principles branch.**  A primitive covector `ell` and a prepared ray `xi=theta ell` calibrate terminal work; the same mechanically selected `theta` enters the entropic tangent.  Arbitrary `vartheta` is an external valuation branch.
7. **Adaptive controls do not bypass pressure formation.**  Controls are held on frozen blocks `m_epsilon`, with `m_epsilon -> infinity`, `epsilon m_epsilon^2 -> 0`, and spectral remainder negligible.  Complete fast-state observation is treated by a no-go theorem.
8. **Controlled second variations retain optimizer response.**  The Schur-complement term is mandatory and separately typed from fixed-law covariance curvature.

## Highest-risk interfaces for external review

- Uniformity of the joint `exp(<xi,kappa>-s tau)` anisotropic spectral packet.
- The exact canonical projective topology and finite-dimensional Gärtner-Ellis/Dawson-Gärtner passage.
- The quantitative vector-displacement/roof-window conditioning estimate.
- Positive definiteness of the full homology transport tensor under local tilts.
- Nonlinear-generator convergence with multiplicative eigenfunction correctors.
- Preparation-before-homogenization diagonal rates.
- Frozen-block controlled pressure consistency.

## Scope guards

- Local analytic formulas hold only on the common simple spectral component.
- The empirical-process theorem is canonical/projective on the declared exposed cylinder domain.
- Nonsmooth phase coexistence outside that domain is a variational classification, not an asserted microscopic realization.
- No many-particle hydrodynamic LDP or control-dependent moving geometry is claimed.
- External line-by-line review is pending.
