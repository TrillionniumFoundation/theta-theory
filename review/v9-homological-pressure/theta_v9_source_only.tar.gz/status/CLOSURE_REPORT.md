# v9 closure report

The v8 scalar-current theory is upgraded on the same compact periodic finite-horizon Sinai platform to a coordinate-free homological theory.

The closed chain in the declared local spectral/projective scope is

```text
Liouville Sinai billiard
  -> full homology displacement plus actual roof
  -> joint twisted Lorentz pressure
  -> physical pressure root H_R(xi)
  -> velocity grad H and transport Hess H
  -> canonical projective empirical-path LDP
  -> quantitative two-sided vector/clock Gibbs conditioning
  -> deterministic ballistic and diffusive homogenization
  -> exact canonical excess-pressure DPP
  -> full non-Gaussian Hamilton-Jacobi generator
  -> calibrated endogenous scalar theta tangent on each homology ray
  -> frozen-block controlled and tangent representations
```

New tools include the coordinate-covariant pressure-root calculus, the growing-central-block Gibbs-conditioning estimate, the local/full-H versus variational-continuation type split, the calibrated-ray theta theorem, and the frozen-block controlled pressure lemma.

Every load-bearing arrow in this scope has a named producer.  Global microscopic phase coexistence, many-particle hydrodynamics, and controls that move the fast scatterer remain stronger theorem classes, not hidden interfaces.
