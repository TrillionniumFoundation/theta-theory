# TL2-HOM-v1

A compact triangular-lattice periodic finite-horizon Sinai billiard with one circular scatterer per cell and radius `R in [9/20,47/100]`.

- natural law: normalized Liouville collision measure;
- primitive mechanical observable: full lattice homology displacement `kappa_R in H_1(T^2;Z)`;
- physical clock: actual free-flight roof `tau_R`;
- preparation field: `xi in H^1(T^2;R)`;
- joint root: `P_R(xi,H_R(xi))=0`;
- physical velocity and transport: `grad H_R(xi)` and `Hess H_R(xi)`;
- clock-corrected fluctuation: `G=kappa_R-v tau_R`;
- empirical-path object: canonical projective rate on the exposed cylinder domain;
- microscopic nonlinear output: the complete local pressure Hamiltonian;
- scalar theta output: on a calibrated ray `xi=theta ell`, the same derived `theta` enters the entropic diffusive tangent.

A lower-semicontinuous convex variational continuation is retained outside the local simple spectral component, but is not identified with microscopic path preparations without a separate global empirical-process LDP.
