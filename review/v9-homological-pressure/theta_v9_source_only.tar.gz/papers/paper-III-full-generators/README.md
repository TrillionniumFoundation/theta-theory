# Canonical Path-Pressure Dynamic Programming and Full Nonlinear Generators from Sinai Billiards

Controlling source: `main.tex`. Normative modules: `sections/part-*.tex`. Platform: `TL2-HOM-v1`. External review pending.
