# External review checklist - v9

Every report must pin the exact commit and theorem labels.

1. Verify the joint homology-clock twisted Lorentz spectral packet.
2. Verify the canonical projective empirical-process topology and local Gärtner-Ellis/projective passage.
3. Check the quantitative two-sided vector-displacement/roof-window conditioning theorem, including growing central blocks.
4. Check basis covariance and the implicit pressure-root derivative identities.
5. Check `G=kappa-v tau`, the vector ASIP, rough lift, and inverse physical clock.
6. Check microscopic convergence to the full local non-Gaussian Hamiltonian and distinguish it from the variational PDE continuation.
7. Check multiplicative/additive corrector compatibility and the preparation diagonal condition.
8. Check that scalar theta-expectation is calibrated by `xi=theta ell`, not by a free risk parameter.
9. Check the frozen-block controlled limit, optimizer-response term, and information no-go.
10. Check tangent path laws, Girsanov/BSDE, and Lax-Oleinik branches.

No build or verifier is mathematical certification.
