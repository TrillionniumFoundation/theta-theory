# Repository governance - v9 candidate

- Exactly five active manuscripts.
- One `main.tex` and one `references.bib` per paper; `sections/part-*.tex` are normative modules.
- Every load-bearing theorem uses `TL2-HOM-v1`.
- Scalar v8, open-billiard v7, and full-cover v6 are benchmarks only.
- Smooth local spectral status and global convex/subgradient status must remain distinct.
- Build, finite-dimensional verification, mathematical proof, and external review are independent statuses.
