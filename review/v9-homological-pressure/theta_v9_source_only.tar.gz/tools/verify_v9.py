#!/usr/bin/env python3
from pathlib import Path
import sys, yaml
root=Path(__file__).resolve().parents[1]
papers=root/'papers'
expected={
'paper-I-homological-ensembles','paper-II-joint-pressure-homogenization',
'paper-III-full-generators','paper-IV-controlled-homology','paper-V-level3-rigidity'}
actual={p.name for p in papers.iterdir() if p.is_dir() and p.name.startswith('paper-')}
assert actual==expected,(actual,expected)
for p in expected:
 d=papers/p
 assert (d/'main.tex').is_file()
 assert (d/'references.bib').is_file()
 assert (d/'REFEREE_GUIDE.md').is_file()
 assert list((d/'sections').glob('part-*.tex'))
 text='\n'.join(x.read_text(errors='ignore') for x in d.rglob('*.tex'))
 assert 'TL2-HOM-v1' in text
 forbidden=['main-v2.tex','main-final.tex','main-round4.tex','main-submission.tex']
 assert not any((d/f).exists() for f in forbidden)
manifest=yaml.safe_load((papers/'SERIES_MANIFEST.yaml').read_text())
assert manifest['load_bearing_platform']=='TL2-HOM-v1'
print('PASS: v9 active tree and platform typing')
