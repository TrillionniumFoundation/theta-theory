#!/usr/bin/env python3
import sympy as s
import numpy as np
# Implicit pressure-root derivative regression.
Ps=s.symbols('Ps', nonzero=True)
P1,P2,P11,P12,P22,P1s,P2s,Pss=s.symbols('P1 P2 P11 P12 P22 P1s P2s Pss')
H1=-P1/Ps; H2=-P2/Ps
H11=-(P11+2*P1s*H1+Pss*H1**2)/Ps
H12=-(P12+P1s*H2+P2s*H1+Pss*H1*H2)/Ps
assert s.simplify(Ps*H11+P11+2*P1s*H1+Pss*H1**2)==0
assert s.simplify(Ps*H12+P12+P1s*H2+P2s*H1+Pss*H1*H2)==0
# Basis covariance regression.
A=s.Matrix([[1,1],[0,1]])
v=s.Matrix([s.Rational(2,5),-s.Rational(1,7)])
D=s.Matrix([[3,s.Rational(1,2)],[s.Rational(1,2),2]])
vp=A.inv()*v
Dp=A.inv()*D*A.inv().T
xi=s.Matrix([s.Rational(3,11),-s.Rational(2,9)])
xip=A.T*xi
assert s.simplify((xi.dot(v))-(xip.dot(vp)))==0
p=s.Matrix([s.Rational(1,3),s.Rational(2,7)])
pp=A.T*p
assert s.simplify((p.T*D*p)[0]-(pp.T*Dp*pp)[0])==0
# Full Hamiltonian quadratic tangent.
e=s.symbols('e')
q1,q2=s.symbols('q1 q2')
C111,C112,C122,C222=s.symbols('C111 C112 C122 C222')
quad=s.Rational(1,2)*(D[0,0]*q1**2+2*D[0,1]*q1*q2+D[1,1]*q2**2)
cubic=(C111*q1**3+3*C112*q1**2*q2+3*C122*q1*q2**2+C222*q2**3)/6
expr=(quad.subs({q1:e*q1,q2:e*q2})+cubic.subs({q1:e*q1,q2:e*q2}))/e**2
assert s.limit(expr,e,0)==quad
# Schur complement symmetry/positivity toy check.
Hzz=s.Matrix([[4,s.Rational(1,2)],[s.Rational(1,2),3]])
B=s.Matrix([[1,2],[0,1]])
C=s.Matrix([[5,0],[0,4]])
S=C-B*Hzz.inv()*B.T
assert S==S.T
assert all(ev>0 for ev in [float(x) for x in S.eigenvals().keys()])
print('PASS: implicit root, basis covariance, full-H tangent, saddle Schur complement')
# Calibrated homology-ray theta invariance under basis change.
theta=s.Rational(7,13)
ell=s.Matrix([s.Rational(2,3),-s.Rational(1,5)])
ellp=A.T*ell
xi_ray=theta*ell
xi_ray_p=theta*ellp
assert xi_ray_p==A.T*xi_ray
dray=(ell.T*D*ell)[0]
dray_p=(ellp.T*Dp*ellp)[0]
assert s.simplify(dray-dray_p)==0
assert s.simplify(theta*dray/2-theta*dray_p/2)==0
# A logarithmic frozen block satisfies the declared separation gates.
import math
rho=0.45
for eps in [1e-4,1e-6,1e-8]:
    m=math.ceil(3.0*math.log(1/eps)/abs(math.log(rho)))
    assert eps*m*m < 0.2
    assert rho**m/(eps*m) < 1e-4
print('PASS: calibrated theta ray and frozen-block gates')
