# TL2-HOM-v1

A compact triangular-lattice periodic finite-horizon Sinai billiard with natural Liouville collision measure, actual free-flight time, and the full lattice homology displacement cocycle.

The local load-bearing domain is the common simple spectral component of the joint twist

```text
exp(<xi,kappa_R> - s tau_R).
```

Within that domain:

- `P_R(xi,H_R(xi))=0` defines physical pressure;
- `grad H_R` is ballistic velocity;
- `Hess H_R` is the clock-corrected transport tensor;
- central vector/clock conditioning selects the same-billiard canonical preparation;
- the full centered Hamiltonian retains all available current cumulants;
- a one-dimensional ray `xi=theta ell` supplies a mechanically calibrated scalar theta-expectation.

The global convex object is a variational PDE continuation unless global microscopic realization is proved separately.
